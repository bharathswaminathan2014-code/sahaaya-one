package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AccessibilityProfile
import com.example.data.model.EmergencyStatus
import com.example.data.model.HapticPatternType
import com.example.data.model.OutputChannel
import com.example.service.AdaptiveOutputRouter
import com.example.service.EmergencyManager
import com.example.service.HapticManager
import com.example.service.TextToSpeechManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
@OptIn(ExperimentalCoroutinesApi::class)
class SahaayaOneUnitTest {

    private lateinit var context: Context
    private lateinit var hapticManager: HapticManager
    private lateinit var ttsManager: TextToSpeechManager
    private lateinit var router: AdaptiveOutputRouter

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        hapticManager = HapticManager(context)
        ttsManager = TextToSpeechManager(context)
        router = AdaptiveOutputRouter(ttsManager, hapticManager)
    }

    @Test
    fun testAdaptiveRouter_VisualProfile_EnablesSpeechAndHaptic() {
        val decision = router.route(
            profile = AccessibilityProfile.VISUAL,
            task = AdaptiveOutputRouter.TaskType.SEE_DESCRIPTION,
            content = "A clear hallway with a doorway on the left."
        )

        assertTrue("Visual profile must include SPEECH channel", decision.channels.contains(OutputChannel.SPEECH))
        assertTrue("Visual profile must include HAPTIC channel", decision.channels.contains(OutputChannel.HAPTIC))
        assertTrue(decision.shouldSpeak)
        assertTrue(decision.shouldVibrate)
    }

    @Test
    fun testAdaptiveRouter_HearingProfile_EnablesVisualAlertAndHaptic() {
        val decision = router.route(
            profile = AccessibilityProfile.HEARING,
            task = AdaptiveOutputRouter.TaskType.HEAR_SOUND_ALERT,
            content = "Possible doorbell detected."
        )

        assertTrue("Hearing profile must include VISUAL_ALERT channel", decision.channels.contains(OutputChannel.VISUAL_ALERT))
        assertTrue("Hearing profile must include HAPTIC channel", decision.channels.contains(OutputChannel.HAPTIC))
        assertTrue(decision.showVisualAlert)
        assertTrue(decision.shouldVibrate)
        assertFalse("Hearing profile should not speak unless forced", decision.shouldSpeak)
    }

    @Test
    fun testAdaptiveRouter_MultipleProfile_EnablesAllModalities() {
        val decision = router.route(
            profile = AccessibilityProfile.MULTIPLE,
            task = AdaptiveOutputRouter.TaskType.GENERAL_NOTIFICATION,
            content = "SAHAAYA ONE is ready."
        )

        assertTrue(decision.channels.contains(OutputChannel.SPEECH))
        assertTrue(decision.channels.contains(OutputChannel.VISUAL_ALERT))
        assertTrue(decision.channels.contains(OutputChannel.HAPTIC))
        assertTrue(decision.shouldSpeak)
        assertTrue(decision.shouldVibrate)
        assertTrue(decision.showVisualAlert)
    }

    @Test
    fun testEmergencyManager_InitialStateAndCancellation() = runTest {
        val testScope = TestScope()
        val emergencyManager = EmergencyManager(context, testScope, hapticManager)

        assertEquals(EmergencyStatus.IDLE, emergencyManager.state.value.status)

        // Initiate request -> requires confirmation
        emergencyManager.initiateEmergencyRequest()
        assertEquals(EmergencyStatus.CONFIRMATION_REQUIRED, emergencyManager.state.value.status)

        // User cancels
        emergencyManager.cancelEmergency()
        assertEquals(EmergencyStatus.CANCELLED, emergencyManager.state.value.status)
    }

    @Test
    fun testEmergencyManager_NotConfiguredState() = runTest {
        val testScope = TestScope()
        val emergencyManager = EmergencyManager(context, testScope, hapticManager)

        emergencyManager.confirmAndStartCountdown("")
        assertEquals(EmergencyStatus.NOT_CONFIGURED, emergencyManager.state.value.status)
    }
}
