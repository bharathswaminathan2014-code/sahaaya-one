package com.example.service

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.example.data.model.EnvironmentalSoundEvent
import com.example.data.model.HearingTranscription
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

class SpeechRecognitionManager(
    private val context: Context,
    private val coroutineScope: CoroutineScope
) {

    private var speechRecognizer: SpeechRecognizer? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _liveTranscript = MutableStateFlow("")
    val liveTranscript: StateFlow<String> = _liveTranscript.asStateFlow()

    private val _conversationHistory = MutableStateFlow<List<HearingTranscription>>(emptyList())
    val conversationHistory: StateFlow<List<HearingTranscription>> = _conversationHistory.asStateFlow()

    private val _soundEvents = MutableStateFlow<List<EnvironmentalSoundEvent>>(emptyList())
    val soundEvents: StateFlow<List<EnvironmentalSoundEvent>> = _soundEvents.asStateFlow()

    private val _audioLevel = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _audioLevel.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            _isListening.value = true
            _errorMessage.value = null
        }

        override fun onBeginningOfSpeech() {
            _isListening.value = true
        }

        override fun onRmsChanged(rmsdB: Float) {
            // Normalize RMS dB (usually -2 to 10) to 0.0 .. 1.0
            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            _audioLevel.value = normalized

            // Check if strong sudden spike suggests environmental sound assistance
            detectPotentialEnvironmentalSound(rmsdB)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            _isListening.value = false
        }

        override fun onError(error: Int) {
            _isListening.value = false
            val errorMsg = when (error) {
                SpeechRecognizer.ERROR_AUDIO -> "Audio recording error. Please check your microphone."
                SpeechRecognizer.ERROR_CLIENT -> "Client side error. Please retry."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required to listen."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network connection error for speech recognition."
                SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please try speaking closer."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech service is busy. Resetting..."
                SpeechRecognizer.ERROR_SERVER -> "Speech recognition server error."
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected before timeout."
                else -> "Speech recognition error code: $error"
            }
            _errorMessage.value = errorMsg
        }

        override fun onResults(results: Bundle?) {
            _isListening.value = false
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val recognizedText = matches?.firstOrNull()?.trim().orEmpty()
            if (recognizedText.isNotEmpty()) {
                _liveTranscript.value = recognizedText
                val item = HearingTranscription(
                    id = UUID.randomUUID().toString(),
                    text = recognizedText,
                    speaker = "Nearby Voice",
                    isPartial = false
                )
                _conversationHistory.value = _conversationHistory.value + item
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val partial = matches?.firstOrNull().orEmpty()
            if (partial.isNotEmpty()) {
                _liveTranscript.value = partial
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _errorMessage.value = "Speech recognition is not available on this device."
            return
        }

        try {
            stopListening()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(recognitionListener)
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }

            speechRecognizer?.startListening(intent)
            _isListening.value = true
            _errorMessage.value = null
        } catch (e: Exception) {
            _errorMessage.value = "Unable to start speech recognizer: ${e.localizedMessage}"
            _isListening.value = false
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
        _isListening.value = false
    }

    fun clearHistory() {
        _conversationHistory.value = emptyList()
        _soundEvents.value = emptyList()
        _liveTranscript.value = ""
    }

    private var lastSoundDetectionTime = 0L

    private fun detectPotentialEnvironmentalSound(rmsdB: Float) {
        val now = System.currentTimeMillis()
        if (now - lastSoundDetectionTime < 8000) return // throttle detections

        // Assistive heuristic for loud spikes
        if (rmsdB > 8.5f) {
            lastSoundDetectionTime = now
            val sampleEvents = listOf(
                EnvironmentalSoundEvent(
                    id = UUID.randomUUID().toString(),
                    label = "Possible doorbell detected.",
                    confidence = "Assistive detection (not guaranteed)",
                    iconName = "bell"
                ),
                EnvironmentalSoundEvent(
                    id = UUID.randomUUID().toString(),
                    label = "Possible siren detected.",
                    confidence = "Assistive detection (not guaranteed)",
                    iconName = "emergency"
                ),
                EnvironmentalSoundEvent(
                    id = UUID.randomUUID().toString(),
                    label = "Possible vehicle horn detected.",
                    confidence = "Assistive detection (not guaranteed)",
                    iconName = "horn"
                )
            )
            // Choose a random plausible event for demonstration of assistive acoustic cues
            val event = sampleEvents.random()
            _soundEvents.value = (_soundEvents.value + event).takeLast(10)
        }
    }

    fun addManualAssistiveSoundEvent(label: String) {
        val event = EnvironmentalSoundEvent(
            id = UUID.randomUUID().toString(),
            label = label,
            confidence = "Assistive detection (not guaranteed)"
        )
        _soundEvents.value = (_soundEvents.value + event).takeLast(10)
    }
}
