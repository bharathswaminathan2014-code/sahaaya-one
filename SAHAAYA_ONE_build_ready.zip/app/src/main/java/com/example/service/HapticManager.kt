package com.example.service

import android.content.Context
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.data.model.HapticPatternType

class HapticManager(private val context: Context) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    /**
     * Triggers phone haptic feedback according to the SAHAAYA ONE haptic vocabulary.
     * intensity: 0.0 to 1.0 multiplier.
     */
    fun triggerPattern(pattern: HapticPatternType, intensity: Float = 1.0f) {
        if (vibrator == null || !vibrator.hasVibrator()) return

        val clampedIntensity = intensity.coerceIn(0.1f, 1.0f)
        val amplitude = (clampedIntensity * 255).toInt().coerceIn(1, 255)

        when (pattern) {
            HapticPatternType.NOTIFICATION -> {
                // 1 short pulse = notification
                playTimings(longArrayOf(0, 80), intArrayOf(0, amplitude))
            }
            HapticPatternType.ACTIVITY -> {
                // 2 short pulses = conversation/activity
                playTimings(longArrayOf(0, 70, 90, 70), intArrayOf(0, amplitude, 0, amplitude))
            }
            HapticPatternType.IMPORTANT_ALERT -> {
                // 1 long pulse = important alert
                playTimings(longArrayOf(0, 350), intArrayOf(0, amplitude))
            }
            HapticPatternType.EMERGENCY -> {
                // 3 pulses = emergency
                playTimings(
                    longArrayOf(0, 180, 100, 180, 100, 250),
                    intArrayOf(0, amplitude, 0, amplitude, 0, 255)
                )
            }
            HapticPatternType.HIGH_PRIORITY -> {
                // Repeated pulses = high-priority attention
                playTimings(
                    longArrayOf(0, 80, 60, 80, 60, 80, 60, 80),
                    intArrayOf(0, amplitude, 0, amplitude, 0, amplitude, 0, amplitude)
                )
            }
        }
    }

    private fun playTimings(timings: LongArray, amplitudes: IntArray) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && vibrator?.hasAmplitudeControl() == true) {
                val effect = VibrationEffect.createWaveform(timings, amplitudes, -1)
                vibrator.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(timings, -1)
            }
        } catch (_: Exception) {
            // Fallback for devices with restrictive vibration policies
            try {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(100)
            } catch (_: Exception) {}
        }
    }

    fun stop() {
        try {
            vibrator?.cancel()
        } catch (_: Exception) {}
    }
}
