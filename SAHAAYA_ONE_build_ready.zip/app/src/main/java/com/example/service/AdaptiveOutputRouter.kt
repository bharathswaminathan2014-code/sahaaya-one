package com.example.service

import com.example.data.model.AccessibilityProfile
import com.example.data.model.HapticPatternType
import com.example.data.model.OutputChannel

class AdaptiveOutputRouter(
    private val ttsManager: TextToSpeechManager,
    private val hapticManager: HapticManager
) {

    data class RoutingDecision(
        val channels: Set<OutputChannel>,
        val shouldSpeak: Boolean,
        val shouldVibrate: Boolean,
        val hapticPattern: HapticPatternType,
        val showVisualAlert: Boolean
    )

    enum class TaskType {
        SEE_DESCRIPTION,
        SEE_OCR_TEXT,
        HEAR_SOUND_ALERT,
        COMMUNICATION_SPEAK,
        EMERGENCY_ALERT,
        GENERAL_NOTIFICATION,
        ASSISTANT_RESPONSE
    }

    fun route(
        profile: AccessibilityProfile,
        task: TaskType,
        content: String,
        customHaptic: HapticPatternType? = null,
        intensity: Float = 1.0f,
        forceSpeech: Boolean = false
    ): RoutingDecision {
        val channels = mutableSetOf<OutputChannel>(OutputChannel.TEXT)

        var defaultPattern = customHaptic ?: when (task) {
            TaskType.EMERGENCY_ALERT -> HapticPatternType.EMERGENCY
            TaskType.HEAR_SOUND_ALERT -> HapticPatternType.IMPORTANT_ALERT
            TaskType.SEE_DESCRIPTION, TaskType.SEE_OCR_TEXT -> HapticPatternType.ACTIVITY
            TaskType.COMMUNICATION_SPEAK -> HapticPatternType.NOTIFICATION
            TaskType.ASSISTANT_RESPONSE -> HapticPatternType.NOTIFICATION
            TaskType.GENERAL_NOTIFICATION -> HapticPatternType.NOTIFICATION
        }

        var shouldSpeak = false
        var shouldVibrate = false
        var showVisualAlert = false

        when (profile) {
            AccessibilityProfile.VISUAL -> {
                // High contrast text + automatic speech + tactile alerts
                channels.add(OutputChannel.SPEECH)
                channels.add(OutputChannel.HAPTIC)
                shouldSpeak = true
                shouldVibrate = true
            }
            AccessibilityProfile.HEARING -> {
                // Visual prominence + haptic pulses, no unsolicited TTS unless forced
                channels.add(OutputChannel.VISUAL_ALERT)
                channels.add(OutputChannel.HAPTIC)
                showVisualAlert = true
                shouldVibrate = true
                shouldSpeak = forceSpeech
            }
            AccessibilityProfile.COMMUNICATION -> {
                // Focus on text and visual confirmation
                channels.add(OutputChannel.VISUAL_ALERT)
                channels.add(OutputChannel.HAPTIC)
                shouldVibrate = true
                shouldSpeak = forceSpeech
            }
            AccessibilityProfile.MULTIPLE -> {
                // Multi-sensory reinforcement
                channels.add(OutputChannel.SPEECH)
                channels.add(OutputChannel.VISUAL_ALERT)
                channels.add(OutputChannel.HAPTIC)
                shouldSpeak = true
                shouldVibrate = true
                showVisualAlert = true
            }
        }

        // Execute physical outputs
        if (shouldVibrate) {
            hapticManager.triggerPattern(defaultPattern, intensity)
        }

        if (shouldSpeak && content.isNotBlank()) {
            ttsManager.speak(content)
        }

        return RoutingDecision(
            channels = channels,
            shouldSpeak = shouldSpeak,
            shouldVibrate = shouldVibrate,
            hapticPattern = defaultPattern,
            showVisualAlert = showVisualAlert
        )
    }
}
