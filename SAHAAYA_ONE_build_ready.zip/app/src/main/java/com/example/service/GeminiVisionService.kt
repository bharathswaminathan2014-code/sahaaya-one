package com.example.service

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

/**
 * Service for routing vision AI, OCR, and assistive communication queries
 * strictly through the secure SAHAAYA ONE backend server.
 *
 * Direct client-side Gemini calls with embedded API keys are strictly forbidden.
 * Architecture: ANDROID -> SAHAAYA ONE BACKEND -> GEMINI
 */
class GeminiVisionService(
    private var backendBaseUrl: String = "https://ais-dev-4iwdf4ezdwf5zlwnagj3wa-43613127378.asia-east1.run.app"
) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun updateBackendUrl(newUrl: String) {
        backendBaseUrl = newUrl.trimEnd('/')
    }

    // Optional user-supplied Gemini key, stored only on this phone (never in the APK or source).
    // When set, requests go straight to Gemini; when blank, the backend URL is used.
    @Volatile
    private var apiKey: String = ""

    fun updateApiKey(newKey: String) {
        apiKey = newKey.trim()
    }

    private fun Bitmap.toBase64Jpeg(): String {
        val maxDimension = 1280
        val ratio = (width.toFloat() / height.toFloat())
        val targetWidth: Int
        val targetHeight: Int
        if (width > height) {
            targetWidth = width.coerceAtMost(maxDimension)
            targetHeight = (targetWidth / ratio).toInt()
        } else {
            targetHeight = height.coerceAtMost(maxDimension)
            targetWidth = (targetHeight * ratio).toInt()
        }

        val scaled = if (targetWidth != width || targetHeight != height) {
            Bitmap.createScaledBitmap(this, targetWidth, targetHeight, true)
        } else {
            this
        }

        val outputStream = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    sealed class VisionResult {
        data class Success(val text: String) : VisionResult()
        data class Error(val message: String) : VisionResult()
    }

    /**
     * Describe the captured scene for visual accessibility via the SAHAAYA ONE backend.
     */
    suspend fun describeScene(bitmap: Bitmap): VisionResult = withContext(Dispatchers.IO) {
        val prompt = "You are the vision companion of SAHAAYA ONE, an assistive app for users with visual disabilities. " +
                "Carefully describe this image clearly, concisely, and objectively. " +
                "Detail prominent objects, people, orientation, indoor/outdoor setting, and physical obstacles or pathways. " +
                "CRITICAL INSTRUCTION: Do NOT claim that the scene is safe or that no hazards exist. " +
                "Limit the description to 3 to 4 helpful, easy-to-understand sentences."

        val base64Image = try {
            bitmap.toBase64Jpeg()
        } catch (e: Exception) {
            return@withContext VisionResult.Error("Failed to process image format: ${e.message}")
        }

        val payload = JSONObject().apply {
            put("image", base64Image)
            put("prompt", prompt)
            put("task", "describe")
        }

        val result = postToBackend("/api/vision/analyze", payload)
        if (result is VisionResult.Success) {
            result
        } else {
            VisionResult.Error("AI analysis is unavailable. Please try again. (${(result as? VisionResult.Error)?.message ?: "unknown"})")
        }
    }

    /**
     * Read visible printed or signage text using OCR via the SAHAAYA ONE backend.
     */
    suspend fun readText(bitmap: Bitmap): VisionResult = withContext(Dispatchers.IO) {
        val prompt = "You are the OCR reading engine for SAHAAYA ONE. " +
                "Extract and transcribe all visible printed, handwritten, or signage text in this image verbatim. " +
                "If there is no visible or readable text in the image, reply ONLY with the exact text: 'No readable text detected.' " +
                "Do not add speculative interpretations or filler words."

        val base64Image = try {
            bitmap.toBase64Jpeg()
        } catch (e: Exception) {
            return@withContext VisionResult.Error("Failed to process image format: ${e.message}")
        }

        val payload = JSONObject().apply {
            put("image", base64Image)
            put("prompt", prompt)
            put("task", "ocr")
        }

        // Try /api/vision/ocr endpoint first, fallback to /api/vision/analyze
        val result = postToBackend("/api/vision/ocr", payload).let { res ->
            if (res is VisionResult.Success) res else postToBackend("/api/vision/analyze", payload)
        }

        if (result is VisionResult.Success) {
            val trimmed = result.text.trim()
            if (trimmed.isEmpty() || trimmed.contains("No readable text detected", ignoreCase = true)) {
                VisionResult.Success("No readable text detected.")
            } else {
                VisionResult.Success(trimmed)
            }
        } else {
            VisionResult.Error("Text reading is unavailable. Please try again. (${(result as? VisionResult.Error)?.message ?: "unknown"})")
        }
    }

    /**
     * Answer a specific user question regarding the captured image via the SAHAAYA ONE backend.
     */
    suspend fun askImageQuestion(bitmap: Bitmap, question: String): VisionResult = withContext(Dispatchers.IO) {
        val base64Image = try {
            bitmap.toBase64Jpeg()
        } catch (e: Exception) {
            return@withContext VisionResult.Error("Failed to process image format: ${e.message}")
        }

        val payload = JSONObject().apply {
            put("image", base64Image)
            put("question", question)
            put("prompt", "You are the accessibility assistant for SAHAAYA ONE. Based strictly on this captured image, answer: '$question'. Be helpful, honest, concise, and do not make unsupported safety claims.")
        }

        val result = postToBackend("/api/vision/ask", payload).let { res ->
            if (res is VisionResult.Success) res else postToBackend("/api/vision/analyze", payload)
        }

        if (result is VisionResult.Success) {
            result
        } else {
            VisionResult.Error("AI question answering is unavailable. Please try again. (${(result as? VisionResult.Error)?.message ?: "unknown"})")
        }
    }

    /**
     * Generate communication suggestions based on a user-provided prompt or context.
     * Output is NEVER spoken automatically; requires user confirmation.
     */
    suspend fun generateCommunicationSuggestions(contextPrompt: String): List<String> = withContext(Dispatchers.IO) {
        val payload = JSONObject().apply {
            put("scenario", contextPrompt)
            put("prompt", "You are the communication assistant for SAHAAYA ONE, supporting individuals with speech and communication accessibility needs. Based on the situation: '$contextPrompt', provide 3 clear, polite, natural first-person statements (e.g. 'I would like...', 'Could you please...'). Return only the 3 phrases, each on a new line, without numbering or bullet points.")
        }

        val result = postToBackend("/api/communication/suggest", payload).let { res ->
            if (res is VisionResult.Success) res else postToBackend("/api/chat", payload)
        }

        when (result) {
            is VisionResult.Success -> {
                result.text.lines()
                    .map { it.trim().removePrefix("-").removePrefix("•").trim() }
                    .filter { it.isNotBlank() }
                    .take(3)
            }
            is VisionResult.Error -> emptyList()
        }
    }

    /**
     * Accessibility assistant request routing via the SAHAAYA ONE backend.
     */
    suspend fun assistantQuery(userMessage: String): VisionResult = withContext(Dispatchers.IO) {
        val payload = JSONObject().apply {
            put("message", userMessage)
            put("prompt", "You are SAHAAYA ONE's built-in accessibility assistant. You help users with visual, hearing, and communication accessibility. Respond helpfully and concisely to: '$userMessage'. Remind them that they can use the SEE tab to inspect surroundings or read text, the HEAR tab for live speech transcription and sound alerts, and the COMMUNICATE tab for quick phrases or speech generation. Keep your answer under 3 sentences.")
        }

        val result = postToBackend("/api/chat", payload)
        if (result is VisionResult.Success) {
            result
        } else {
            VisionResult.Error("AI assistant is unavailable. Please try again.")
        }
    }

    private fun postToBackend(endpoint: String, payload: JSONObject): VisionResult {
        if (apiKey.isNotBlank()) return callGeminiDirect(payload)
        return try {
            val url = "$backendBaseUrl$endpoint"
            val requestBody = payload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val responseBody = response.body?.string() ?: return VisionResult.Error("Empty backend response")
                    if (responseBody.trimStart().startsWith("<")) {
                        return VisionResult.Error("Backend returned a web page (login or cookie check), not an answer.")
                    }
                    val parsedText = parseResponseText(responseBody)
                    if (parsedText.isNotBlank()) {
                        VisionResult.Success(parsedText)
                    } else {
                        VisionResult.Error("Invalid backend response payload")
                    }
                } else {
                    Log.w("GeminiVisionService", "Backend HTTP error ${response.code} at $endpoint")
                    VisionResult.Error("Backend returned HTTP ${response.code}")
                }
            }
        } catch (e: Exception) {
            Log.e("GeminiVisionService", "Backend connection failed at $endpoint: ${e.message}")
            VisionResult.Error("Backend service unavailable. Please check your connection or try again later.")
        }
    }

    /**
     * Calls the Gemini REST API directly using the key the user entered in Settings.
     * Tries a few model names in order, moving on when a model is not found, rate limited, or overloaded.
     */
    private fun callGeminiDirect(payload: JSONObject): VisionResult {
        val prompt = payload.optString("prompt")
        val image = payload.optString("image")

        val parts = JSONArray()
        parts.put(JSONObject().put("text", prompt))
        if (image.isNotEmpty()) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", "image/jpeg").put("data", image)
                )
            )
        }
        val body = JSONObject().put(
            "contents",
            JSONArray().put(JSONObject().put("parts", parts))
        )

        val models = listOf("gemini-flash-latest", "gemini-3.5-flash", "gemini-2.5-flash", "gemini-flash-lite-latest")
        var lastError = "Gemini request failed"
        for (model in models) {
            try {
                val request = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .header("x-goog-api-key", apiKey)
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(request).execute().use { response ->
                    val responseText = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        val answer = extractGeminiText(responseText)
                        return if (answer.isNotBlank()) {
                            VisionResult.Success(answer)
                        } else {
                            VisionResult.Error("Gemini returned no text")
                        }
                    }
                    val errorText = "Gemini error HTTP ${response.code}: ${extractGeminiError(responseText)}"
                    // Model not found (404), rate limited (429) or overloaded/server error (5xx): try the next model.
                    val tryNextModel = response.code == 404 || response.code == 429 || response.code >= 500
                    if (!tryNextModel) return VisionResult.Error(errorText)
                    lastError = errorText
                }
            } catch (e: Exception) {
                Log.e("GeminiVisionService", "Direct Gemini call failed: ${e.message}")
                return VisionResult.Error("Could not reach Gemini: ${e.message}")
            }
        }
        return VisionResult.Error(lastError)
    }

    private fun extractGeminiText(responseBody: String): String {
        return try {
            val parts = JSONObject(responseBody)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
            (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }.trim()
        } catch (_: Exception) {
            ""
        }
    }

    private fun extractGeminiError(responseBody: String): String {
        return try {
            JSONObject(responseBody).getJSONObject("error").getString("message")
        } catch (_: Exception) {
            responseBody.take(200)
        }
    }

    private fun parseResponseText(responseBody: String): String {
        return try {
            val json = JSONObject(responseBody)
            // Support common response formats: text, result, description, or suggestions array
            when {
                json.has("text") -> json.getString("text")
                json.has("result") -> json.getString("result")
                json.has("description") -> json.getString("description")
                json.has("message") -> json.getString("message")
                json.has("suggestions") -> {
                    val arr = json.getJSONArray("suggestions")
                    (0 until arr.length()).joinToString("\n") { arr.getString(it) }
                }
                else -> ""
            }
        } catch (_: Exception) {
            // If response is plain text
            responseBody.trim()
        }
    }
}
