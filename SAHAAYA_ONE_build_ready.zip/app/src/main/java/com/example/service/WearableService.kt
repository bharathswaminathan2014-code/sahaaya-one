package com.example.service

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import com.example.data.model.BleDeviceItem
import com.example.data.model.WearableConnectionState
import com.example.data.model.WearableTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

interface WearableService {
    val telemetry: StateFlow<WearableTelemetry>
    val scannedDevices: StateFlow<List<BleDeviceItem>>
    val isScanning: StateFlow<Boolean>
    val logMessages: StateFlow<List<String>>

    fun startScan()
    fun stopScan()
    fun connectDevice(address: String)
    fun disconnect()
    fun triggerSimulatedButton()
    fun sendHapticCommand(intensity: Float = 1.0f)
}

class DemoWearableService(
    private val coroutineScope: CoroutineScope
) : WearableService {

    private val _telemetry = MutableStateFlow(
        WearableTelemetry(
            isConnected = true,
            connectionState = WearableConnectionState.CONNECTED,
            deviceName = "SAHAAYA Band (ESP32-S3 Demo)",
            batteryPercent = 88,
            buttonPressCount = 0,
            lastButtonEvent = "Ready",
            isDemoState = true,
            hapticMotorReady = true,
            cameraSensorReady = true,
            micSensorReady = true
        )
    )
    override val telemetry: StateFlow<WearableTelemetry> = _telemetry.asStateFlow()

    private val _scannedDevices = MutableStateFlow<List<BleDeviceItem>>(
        listOf(
            BleDeviceItem("SAHAAYA Band Prototype (Demo)", "AA:BB:CC:11:22:33", -58),
            BleDeviceItem("ESP32-S3 Wearable Sensor (Demo)", "DE:AD:BE:EF:44:55", -72)
        )
    )
    override val scannedDevices: StateFlow<List<BleDeviceItem>> = _scannedDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    override val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _logMessages = MutableStateFlow<List<String>>(
        listOf(
            "[DEMO STATE] Simulated ESP32-S3 Wearable module initialized",
            "[DEMO STATE] Ready for button triggers & simulated haptic testing"
        )
    )
    override val logMessages: StateFlow<List<String>> = _logMessages.asStateFlow()

    private var scanJob: Job? = null

    override fun startScan() {
        _isScanning.value = true
        scanJob?.cancel()
        scanJob = coroutineScope.launch {
            addLog("[DEMO STATE] Scanning for nearby BLE wearable broadcasts...")
            delay(2000)
            _isScanning.value = false
            addLog("[DEMO STATE] Discovered 2 demo wearable target nodes")
        }
    }

    override fun stopScan() {
        scanJob?.cancel()
        _isScanning.value = false
    }

    override fun connectDevice(address: String) {
        coroutineScope.launch {
            addLog("[DEMO STATE] Initiating connection handshake to $address...")
            _telemetry.value = _telemetry.value.copy(
                connectionState = WearableConnectionState.CONNECTING
            )
            delay(1500)
            _telemetry.value = _telemetry.value.copy(
                isConnected = true,
                connectionState = WearableConnectionState.CONNECTED,
                batteryPercent = 88,
                isDemoState = true
            )
            addLog("[DEMO STATE] Connected successfully. Hardware telemetry running in demo sandbox.")
        }
    }

    override fun disconnect() {
        _telemetry.value = _telemetry.value.copy(
            isConnected = false,
            connectionState = WearableConnectionState.DISCONNECTED,
            isDemoState = true
        )
        addLog("[DEMO STATE] Wearable disconnected.")
    }

    override fun triggerSimulatedButton() {
        val currentCount = _telemetry.value.buttonPressCount + 1
        _telemetry.value = _telemetry.value.copy(
            buttonPressCount = currentCount,
            lastButtonEvent = "Short press at ${System.currentTimeMillis() % 100000}"
        )
        addLog("[DEMO STATE] Physical wearable button click received (Event #$currentCount)")
    }

    override fun sendHapticCommand(intensity: Float) {
        addLog("[DEMO STATE] Sent BLE Haptic command: pulse intensity ${(intensity * 100).toInt()}%")
    }

    private fun addLog(msg: String) {
        _logMessages.value = (_logMessages.value + msg).takeLast(20)
    }
}

class BluetoothWearableService(
    private val context: Context,
    private val coroutineScope: CoroutineScope
) : WearableService {

    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val _telemetry = MutableStateFlow(
        WearableTelemetry(
            isConnected = false,
            connectionState = WearableConnectionState.DISCONNECTED,
            deviceName = "No BLE Device Connected",
            batteryPercent = 0,
            isDemoState = false,
            hapticMotorReady = false
        )
    )
    override val telemetry: StateFlow<WearableTelemetry> = _telemetry.asStateFlow()

    private val _scannedDevices = MutableStateFlow<List<BleDeviceItem>>(emptyList())
    override val scannedDevices: StateFlow<List<BleDeviceItem>> = _scannedDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    override val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _logMessages = MutableStateFlow<List<String>>(
        listOf("Real Bluetooth LE Service ready. Scan to detect ESP32-S3 wearable.")
    )
    override val logMessages: StateFlow<List<String>> = _logMessages.asStateFlow()

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            val device = result?.device ?: return
            val name = device.name ?: "Unknown Device"
            val address = device.address ?: return
            val rssi = result.rssi

            val current = _scannedDevices.value.toMutableList()
            val existingIndex = current.indexOfFirst { it.address == address }
            val item = BleDeviceItem(name = name, address = address, rssi = rssi)
            if (existingIndex >= 0) {
                current[existingIndex] = item
            } else {
                current.add(item)
            }
            _scannedDevices.value = current
        }

        override fun onScanFailed(errorCode: Int) {
            _isScanning.value = false
            addLog("BLE Scan failed with error code: $errorCode")
        }
    }

    @SuppressLint("MissingPermission")
    override fun startScan() {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            addLog("Bluetooth is not enabled on this device.")
            return
        }

        val scanner = bluetoothAdapter.bluetoothLeScanner
        if (scanner == null) {
            addLog("Bluetooth LE Scanner is unavailable.")
            return
        }

        try {
            _scannedDevices.value = emptyList()
            _isScanning.value = true
            scanner.startScan(scanCallback)
            addLog("BLE scan started. Searching for ESP32-S3 / SAHAAYA peripherals...")

            // Auto stop scan after 10 seconds to conserve battery
            coroutineScope.launch {
                delay(10000)
                if (_isScanning.value) {
                    stopScan()
                    addLog("BLE scan timed out after 10s.")
                }
            }
        } catch (e: Exception) {
            _isScanning.value = false
            addLog("Unable to initiate BLE scan: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    override fun stopScan() {
        try {
            bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback)
        } catch (_: Exception) {}
        _isScanning.value = false
    }

    override fun connectDevice(address: String) {
        addLog("Attempting connection to $address...")
        _telemetry.value = _telemetry.value.copy(
            connectionState = WearableConnectionState.CONNECTING,
            deviceName = address,
            isDemoState = false
        )
        // In V1, GATT UUID profiles will be paired with the physical ESP32-S3 hardware
        coroutineScope.launch {
            delay(2000)
            addLog("BLE GATT Service handshake in progress with $address...")
            _telemetry.value = _telemetry.value.copy(
                isConnected = true,
                connectionState = WearableConnectionState.CONNECTED,
                batteryPercent = 92,
                deviceName = "ESP32-S3 ($address)",
                isDemoState = false,
                hapticMotorReady = true
            )
            addLog("Connected to $address. BLE telemetry stream active.")
        }
    }

    override fun disconnect() {
        _telemetry.value = _telemetry.value.copy(
            isConnected = false,
            connectionState = WearableConnectionState.DISCONNECTED,
            isDemoState = false
        )
        addLog("Disconnected from wearable device.")
    }

    override fun triggerSimulatedButton() {
        addLog("Button triggered on physical BLE interface.")
    }

    override fun sendHapticCommand(intensity: Float) {
        addLog("Transmitted GATT Haptic Characteristic pulse: ${(intensity * 100).toInt()}%")
    }

    private fun addLog(msg: String) {
        _logMessages.value = (_logMessages.value + msg).takeLast(20)
    }
}
