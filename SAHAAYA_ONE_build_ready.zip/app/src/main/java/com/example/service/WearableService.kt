package com.example.service

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanSettings
import android.os.ParcelUuid
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import com.example.data.model.BleDeviceItem
import com.example.data.model.WearableConnectionState
import com.example.data.model.WearableTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

interface WearableService {
    val telemetry: StateFlow<WearableTelemetry>
    val scannedDevices: StateFlow<List<BleDeviceItem>>
    val isScanning: StateFlow<Boolean>
    val logMessages: StateFlow<List<String>>

    fun startScan()
    fun stopScan()
    fun connectDevice(address: String)
    fun disconnect()
    fun triggerSimulatedButton()
    fun sendHapticCommand(intensity: Float = 1.0f)

    /** Button events from the wearable: 1 = single press, 2 = double press, 3 = long press. */
    val buttonEvents: Flow<Int> get() = emptyFlow()

    /** Sends a haptic pattern (1..5) to the wearable. Default: does nothing. */
    fun sendHapticPattern(pattern: Int, intensity: Float) {}
}

class DemoWearableService(
    private val coroutineScope: CoroutineScope
) : WearableService {

    private val _telemetry = MutableStateFlow(
        WearableTelemetry(
            isConnected = true,
            connectionState = WearableConnectionState.CONNECTED,
            deviceName = "SAHAAYA Band (ESP32-S3 Demo)",
            batteryPercent = 88,
            buttonPressCount = 0,
            lastButtonEvent = "Ready",
            isDemoState = true,
            hapticMotorReady = true,
            cameraSensorReady = true,
            micSensorReady = true
        )
    )
    override val telemetry: StateFlow<WearableTelemetry> = _telemetry.asStateFlow()

    private val _scannedDevices = MutableStateFlow<List<BleDeviceItem>>(
        listOf(
            BleDeviceItem("SAHAAYA Band Prototype (Demo)", "AA:BB:CC:11:22:33", -58),
            BleDeviceItem("ESP32-S3 Wearable Sensor (Demo)", "DE:AD:BE:EF:44:55", -72)
        )
    )
    override val scannedDevices: StateFlow<List<BleDeviceItem>> = _scannedDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    override val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _logMessages = MutableStateFlow<List<String>>(
        listOf(
            "[DEMO STATE] Simulated ESP32-S3 Wearable module initialized",
            "[DEMO STATE] Ready for button triggers & simulated haptic testing"
        )
    )
    override val logMessages: StateFlow<List<String>> = _logMessages.asStateFlow()

    private var scanJob: Job? = null

    override fun startScan() {
        _isScanning.value = true
        scanJob?.cancel()
        scanJob = coroutineScope.launch {
            addLog("[DEMO STATE] Scanning for nearby BLE wearable broadcasts...")
            delay(2000)
            _isScanning.value = false
            addLog("[DEMO STATE] Discovered 2 demo wearable target nodes")
        }
    }

    override fun stopScan() {
        scanJob?.cancel()
        _isScanning.value = false
    }

    override fun connectDevice(address: String) {
        coroutineScope.launch {
            addLog("[DEMO STATE] Initiating connection handshake to $address...")
            _telemetry.value = _telemetry.value.copy(
                connectionState = WearableConnectionState.CONNECTING
            )
            delay(1500)
            _telemetry.value = _telemetry.value.copy(
                isConnected = true,
                connectionState = WearableConnectionState.CONNECTED,
                batteryPercent = 88,
                isDemoState = true
            )
            addLog("[DEMO STATE] Connected successfully. Hardware telemetry running in demo sandbox.")
        }
    }

    override fun disconnect() {
        _telemetry.value = _telemetry.value.copy(
            isConnected = false,
            connectionState = WearableConnectionState.DISCONNECTED,
            isDemoState = true
        )
        addLog("[DEMO STATE] Wearable disconnected.")
    }

    override fun triggerSimulatedButton() {
        val currentCount = _telemetry.value.buttonPressCount + 1
        _telemetry.value = _telemetry.value.copy(
            buttonPressCount = currentCount,
            lastButtonEvent = "Short press at ${System.currentTimeMillis() % 100000}"
        )
        addLog("[DEMO STATE] Physical wearable button click received (Event #$currentCount)")
    }

    override fun sendHapticCommand(intensity: Float) {
        addLog("[DEMO STATE] Sent BLE Haptic command: pulse intensity ${(intensity * 100).toInt()}%")
    }

    private fun addLog(msg: String) {
        _logMessages.value = (_logMessages.value + msg).takeLast(20)
    }
}

class BluetoothWearableService(
    private val context: Context,
    private val coroutineScope: CoroutineScope
) : WearableService {

    companion object {
        // These UUIDs must match firmware/sahaaya_band/sahaaya_band.ino
        val SERVICE_UUID: UUID = UUID.fromString("7d1f0001-3b5a-4c1e-9a10-5a4a4f4e4531")
        val BUTTON_UUID: UUID = UUID.fromString("7d1f0002-3b5a-4c1e-9a10-5a4a4f4e4531")
        val HAPTIC_UUID: UUID = UUID.fromString("7d1f0003-3b5a-4c1e-9a10-5a4a4f4e4531")
        val BATTERY_UUID: UUID = UUID.fromString("7d1f0004-3b5a-4c1e-9a10-5a4a4f4e4531")
        val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private var activeGatt: BluetoothGatt? = null
    private var hapticChar: BluetoothGattCharacteristic? = null
    private val pendingNotify = ArrayDeque<BluetoothGattCharacteristic>()

    private val _telemetry = MutableStateFlow(
        WearableTelemetry(
            isConnected = false,
            connectionState = WearableConnectionState.DISCONNECTED,
            deviceName = "No BLE Device Connected",
            batteryPercent = 0,
            isDemoState = false,
            hapticMotorReady = false,
            cameraSensorReady = false,
            micSensorReady = false
        )
    )
    override val telemetry: StateFlow<WearableTelemetry> = _telemetry.asStateFlow()

    private val _scannedDevices = MutableStateFlow<List<BleDeviceItem>>(emptyList())
    override val scannedDevices: StateFlow<List<BleDeviceItem>> = _scannedDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    override val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _logMessages = MutableStateFlow<List<String>>(
        listOf("Real Bluetooth LE service ready. Power on the SAHAAYA band, then scan.")
    )
    override val logMessages: StateFlow<List<String>> = _logMessages.asStateFlow()

    // Button events from the band: 1 = single press, 2 = double press, 3 = long press
    private val _buttonEvents = MutableSharedFlow<Int>(extraBufferCapacity = 8)
    override val buttonEvents: SharedFlow<Int> = _buttonEvents.asSharedFlow()

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            val device = result?.device ?: return
            val name = result.scanRecord?.deviceName ?: device.name ?: "SAHAAYA Band"
            val address = device.address ?: return
            val rssi = result.rssi

            val current = _scannedDevices.value.toMutableList()
            val existingIndex = current.indexOfFirst { it.address == address }
            val item = BleDeviceItem(name = name, address = address, rssi = rssi)
            if (existingIndex >= 0) {
                current[existingIndex] = item
            } else {
                current.add(item)
            }
            _scannedDevices.value = current
        }

        override fun onScanFailed(errorCode: Int) {
            _isScanning.value = false
            addLog("BLE scan failed with error code: $errorCode")
        }
    }

    @SuppressLint("MissingPermission")
    override fun startScan() {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            addLog("Bluetooth is not enabled on this device.")
            return
        }

        val scanner = bluetoothAdapter.bluetoothLeScanner
        if (scanner == null) {
            addLog("Bluetooth LE scanner is unavailable.")
            return
        }

        try {
            _scannedDevices.value = emptyList()
            _isScanning.value = true
            // Only list devices that advertise the SAHAAYA band service
            val filters = listOf(
                ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE_UUID)).build()
            )
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build()
            scanner.startScan(filters, settings, scanCallback)
            addLog("Scanning for SAHAAYA bands...")

            // Auto stop scan after 10 seconds to conserve battery
            coroutineScope.launch {
                delay(10000)
                if (_isScanning.value) {
                    stopScan()
                    addLog("Scan finished. If no band was found: check it is powered on and close to the phone.")
                }
            }
        } catch (e: Exception) {
            _isScanning.value = false
            addLog("Unable to start BLE scan: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    override fun stopScan() {
        try {
            bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback)
        } catch (_: Exception) {}
        _isScanning.value = false
    }

    @SuppressLint("MissingPermission")
    override fun connectDevice(address: String) {
        val adapter = bluetoothAdapter
        if (adapter == null) {
            addLog("Bluetooth is not available on this device.")
            return
        }
        stopScan()
        closeGatt()
        try {
            val device = adapter.getRemoteDevice(address)
            _telemetry.value = _telemetry.value.copy(
                isConnected = false,
                connectionState = WearableConnectionState.CONNECTING,
                deviceName = address,
                isDemoState = false
            )
            addLog("Connecting to $address...")
            activeGatt = device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (e: Exception) {
            addLog("Could not start connection: ${e.message}")
            _telemetry.value = _telemetry.value.copy(connectionState = WearableConnectionState.ERROR)
        }
    }

    @SuppressLint("MissingPermission")
    private fun closeGatt() {
        try {
            activeGatt?.disconnect()
            activeGatt?.close()
        } catch (_: Exception) {}
        activeGatt = null
        hapticChar = null
        pendingNotify.clear()
    }

    override fun disconnect() {
        closeGatt()
        _telemetry.value = _telemetry.value.copy(
            isConnected = false,
            connectionState = WearableConnectionState.DISCONNECTED,
            deviceName = "No BLE Device Connected",
            batteryPercent = 0,
            isDemoState = false,
            hapticMotorReady = false
        )
        addLog("Disconnected from wearable device.")
    }

    private val gattCallback = object : BluetoothGattCallback() {

        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                addLog("Link established. Discovering services...")
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                if (status == 133) {
                    addLog("Connection failed (status 133). Try again, or turn phone Bluetooth off and on.")
                } else {
                    addLog("Band disconnected (status $status).")
                }
                try {
                    gatt.close()
                } catch (_: Exception) {}
                if (activeGatt === gatt) {
                    activeGatt = null
                }
                hapticChar = null
                pendingNotify.clear()
                _telemetry.value = _telemetry.value.copy(
                    isConnected = false,
                    connectionState = WearableConnectionState.DISCONNECTED,
                    deviceName = "No BLE Device Connected",
                    batteryPercent = 0,
                    hapticMotorReady = false
                )
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val service = gatt.getService(SERVICE_UUID)
            if (status != BluetoothGatt.GATT_SUCCESS || service == null) {
                addLog("SAHAAYA band service not found on this device. Is it the SAHAAYA band?")
                _telemetry.value = _telemetry.value.copy(connectionState = WearableConnectionState.ERROR)
                gatt.disconnect()
                return
            }

            hapticChar = service.getCharacteristic(HAPTIC_UUID)
            pendingNotify.clear()
            service.getCharacteristic(BUTTON_UUID)?.let { pendingNotify.add(it) }
            service.getCharacteristic(BATTERY_UUID)?.let { pendingNotify.add(it) }

            _telemetry.value = _telemetry.value.copy(
                isConnected = true,
                connectionState = WearableConnectionState.CONNECTED,
                deviceName = gatt.device.name ?: "SAHAAYA Band",
                batteryPercent = -1,
                isDemoState = false,
                hapticMotorReady = hapticChar != null,
                cameraSensorReady = false,
                micSensorReady = false
            )
            addLog("Connected. Enabling button and battery notifications...")
            enableNextNotification(gatt)
        }

        override fun onDescriptorWrite(
            gatt: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int
        ) {
            enableNextNotification(gatt)
        }

        // Android 13+ delivers notifications here
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            handleNotification(characteristic.uuid, value)
        }

        // Android 12 and older deliver notifications here
        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            val bytes = characteristic.value ?: return
            handleNotification(characteristic.uuid, bytes)
        }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun enableNextNotification(gatt: BluetoothGatt) {
        val characteristic = pendingNotify.removeFirstOrNull() ?: return
        gatt.setCharacteristicNotification(characteristic, true)
        val cccd = characteristic.getDescriptor(CCCD_UUID)
        if (cccd == null) {
            addLog("Notification descriptor missing for ${characteristic.uuid}")
            enableNextNotification(gatt)
            return
        }
        cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        gatt.writeDescriptor(cccd)
    }

    private fun handleNotification(uuid: UUID, value: ByteArray) {
        if (value.isEmpty()) return
        val code = value[0].toInt() and 0xFF
        when (uuid) {
            BUTTON_UUID -> {
                val label = when (code) {
                    1 -> "Single press"
                    2 -> "Double press"
                    3 -> "Long press"
                    else -> "Code $code"
                }
                _telemetry.value = _telemetry.value.copy(
                    buttonPressCount = _telemetry.value.buttonPressCount + 1,
                    lastButtonEvent = label
                )
                addLog("Band button: $label")
                _buttonEvents.tryEmit(code)
            }
            BATTERY_UUID -> {
                _telemetry.value = _telemetry.value.copy(
                    batteryPercent = if (code in 0..100) code else -1
                )
            }
        }
    }

    override fun triggerSimulatedButton() {
        // Test button on the Wearable screen: behaves like a single press on the band
        _telemetry.value = _telemetry.value.copy(
            buttonPressCount = _telemetry.value.buttonPressCount + 1,
            lastButtonEvent = "Simulated single press"
        )
        addLog("Simulated single press (test).")
        _buttonEvents.tryEmit(1)
    }

    override fun sendHapticCommand(intensity: Float) {
        sendHapticPattern(1, intensity)
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    override fun sendHapticPattern(pattern: Int, intensity: Float) {
        val gatt = activeGatt ?: return
        val characteristic = hapticChar ?: return
        val level = (intensity.coerceIn(0f, 1f) * 100).toInt()
        try {
            characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            characteristic.value = byteArrayOf(pattern.toByte(), level.toByte())
            val sent = gatt.writeCharacteristic(characteristic)
            addLog("Haptic pattern $pattern at $level%: ${if (sent) "sent" else "not sent"}")
        } catch (e: Exception) {
            addLog("Haptic write failed: ${e.message}")
        }
    }

    private fun addLog(msg: String) {
        _logMessages.update { (it + msg).takeLast(20) }
    }
}
