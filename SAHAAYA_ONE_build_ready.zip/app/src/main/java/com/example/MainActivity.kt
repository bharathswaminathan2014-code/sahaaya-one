package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.ui.SahaayaViewModel
import com.example.ui.navigation.SahaayaNavGraph
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.SahaayaTheme

class MainActivity : ComponentActivity() {

    private val viewModel: SahaayaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SahaayaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = NavyDeep
                ) {
                    SahaayaNavGraph(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    SahaayaTheme { Greeting("Android") }
}

