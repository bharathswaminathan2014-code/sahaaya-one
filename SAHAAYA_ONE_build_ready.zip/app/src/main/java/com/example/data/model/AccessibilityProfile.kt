package com.example.data.model

enum class AccessibilityProfile(val title: String, val description: String) {
    VISUAL(
        title = "Visual",
        description = "High-contrast visual layouts, automatic audio descriptions, spoken feedback, and haptic alerts."
    ),
    HEARING(
        title = "Hearing",
        description = "Visual sound indicators, live captions, transcription logs, and distinct haptic vibration cues."
    ),
    COMMUNICATION(
        title = "Communication",
        description = "Augmentative communication boards, quick assist phrases, AI phrasing suggestions with strict confirmation."
    ),
    MULTIPLE(
        title = "Multiple",
        description = "Comprehensive multi-sensory support combining speech, visual cues, large touch targets, and tactile haptics."
    )
}

enum class OutputChannel {
    TEXT,
    SPEECH,
    VISUAL_ALERT,
    HAPTIC
}

enum class HapticPatternType(val label: String) {
    NOTIFICATION("Notification (1 short pulse)"),
    ACTIVITY("Conversation / Activity (2 short pulses)"),
    IMPORTANT_ALERT("Important Alert (1 long pulse)"),
    EMERGENCY("Emergency (3 pulses)"),
    HIGH_PRIORITY("High-Priority Attention (Repeated pulses)")
}

data class UserPreferences(
    val selectedProfile: AccessibilityProfile = AccessibilityProfile.MULTIPLE,
    val highContrastEnabled: Boolean = true,
    val ttsRate: Float = 1.0f,
    val ttsPitch: Float = 1.0f,
    val hapticIntensity: Float = 1.0f, // 0.0 to 1.0
    val isDemoMode: Boolean = false,
    val emergencyContactName: String = "Guardian / Caregiver",
    val emergencyContactPhone: String = "911",
    val backendUrl: String = "https://ais-dev-4iwdf4ezdwf5zlwnagj3wa-43613127378.asia-east1.run.app"
)
