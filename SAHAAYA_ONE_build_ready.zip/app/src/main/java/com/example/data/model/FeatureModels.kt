package com.example.data.model

import android.graphics.Bitmap

sealed interface SeeMode {
    data object Describe : SeeMode
    data object Read : SeeMode
    data object Ask : SeeMode
}

data class SeeAnalysisState(
    val isLoading: Boolean = false,
    val mode: SeeMode = SeeMode.Describe,
    val capturedBitmap: Bitmap? = null,
    val capturedImageUri: String? = null,
    val resultText: String? = null,
    val extractedText: String? = null,
    val userQuestion: String = "",
    val errorMessage: String? = null,
    val isDemoImage: Boolean = false
)

data class HearingTranscription(
    val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val speaker: String = "Speaker",
    val text: String,
    val isPartial: Boolean = false
)

data class EnvironmentalSoundEvent(
    val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val label: String, // e.g. "Possible doorbell detected."
    val confidence: String = "Assistive detection",
    val iconName: String = "bell"
)

data class HearingState(
    val isListening: Boolean = false,
    val liveTranscript: String = "",
    val conversationHistory: List<HearingTranscription> = emptyList(),
    val soundEvents: List<EnvironmentalSoundEvent> = emptyList(),
    val audioLevel: Float = 0f,
    val isConversationMode: Boolean = false,
    val errorMessage: String? = null
)

data class QuickPhrase(
    val id: String,
    val text: String,
    val category: String = "General"
)

data class CommunicationState(
    val quickPhrases: List<QuickPhrase> = listOf(
        QuickPhrase("1", "I need help.", "Urgent"),
        QuickPhrase("2", "I need water.", "Needs"),
        QuickPhrase("3", "Please wait.", "General"),
        QuickPhrase("4", "Please help me.", "Urgent"),
        QuickPhrase("5", "I don't understand.", "General"),
        QuickPhrase("6", "Call my family.", "Urgent")
    ),
    val customPhrases: List<String> = emptyList(),
    val aiGeneratedSuggestion: String? = null,
    val isGeneratingAiPhrase: Boolean = false,
    val isConfirmedForSpeech: Boolean = false,
    val errorMessage: String? = null
)

enum class EmergencyStatus {
    IDLE,
    CONFIRMATION_REQUIRED,
    COUNTDOWN_ACTIVE,
    CONFIRMED,
    CANCELLED,
    FAILED,
    NO_NETWORK,
    PERMISSION_UNAVAILABLE,
    NOT_CONFIGURED
}

data class EmergencyState(
    val status: EmergencyStatus = EmergencyStatus.IDLE,
    val countdownRemainingSeconds: Int = 5,
    val statusMessage: String = "",
    val timestamp: Long = 0L
)

enum class WearableConnectionState {
    DISCONNECTED,
    SCANNING,
    CONNECTING,
    CONNECTED,
    ERROR
}

data class BleDeviceItem(
    val name: String,
    val address: String,
    val rssi: Int = -60
)

data class WearableTelemetry(
    val isConnected: Boolean = false,
    val connectionState: WearableConnectionState = WearableConnectionState.DISCONNECTED,
    val deviceName: String = "SAHAAYA Band (ESP32-S3)",
    val batteryPercent: Int = 85,
    val buttonPressCount: Int = 0,
    val lastButtonEvent: String = "None",
    val isDemoState: Boolean = true,
    val hapticMotorReady: Boolean = true,
    val cameraSensorReady: Boolean = true,
    val micSensorReady: Boolean = true
)
