package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = CyanAccent,
    onPrimary = NavyDeep,
    primaryContainer = NavyCard,
    onPrimaryContainer = CyanGlow,
    secondary = AmberAccent,
    onSecondary = NavyDeep,
    secondaryContainer = NavyCard,
    onSecondaryContainer = AmberGlow,
    tertiary = AlertRed,
    onTertiary = TextHighContrast,
    background = NavyDeep,
    onBackground = TextHighContrast,
    surface = NavySurface,
    onSurface = TextHighContrast,
    surfaceVariant = NavyCard,
    onSurfaceVariant = TextMediumContrast,
    outline = NavyCardBorder,
    error = AlertRed,
    onError = TextHighContrast
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF00687A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFA6EEFF),
    onPrimaryContainer = Color(0xFF001F26),
    secondary = Color(0xFF7A5900),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDEA4),
    onSecondaryContainer = Color(0xFF261900),
    tertiary = Color(0xFFBA1A1A),
    onTertiary = Color.White,
    background = Color(0xFFFBFDFE),
    onBackground = Color(0xFF191C1D),
    surface = Color(0xFFFBFDFE),
    onSurface = Color(0xFF191C1D),
    surfaceVariant = Color(0xFFDBE4E7),
    onSurfaceVariant = Color(0xFF3F484A),
    outline = Color(0xFF6F797B)
)

@Composable
fun SahaayaTheme(
    darkTheme: Boolean = true, // Default to dark for high contrast accessibility
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    SahaayaTheme(darkTheme = darkTheme, content = content)
}

