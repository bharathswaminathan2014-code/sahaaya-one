package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageCapture.OutputFileOptions
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NavyDeep
import java.io.File
import java.util.concurrent.Executors

@Composable
fun CameraPreviewView(
    onImageCaptured: (Bitmap) -> Unit,
    onDemoImageSelected: () -> Unit,
    isCapturing: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var lensFacing by remember { mutableStateOf(CameraSelector.LENS_FACING_BACK) }
    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }
    var previewView: PreviewView? by remember { mutableStateOf(null) }
    var cameraProvider: ProcessCameraProvider? by remember { mutableStateOf(null) }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) {
        onDispose {
            try {
                cameraProvider?.unbindAll()
                cameraExecutor.shutdown()
            } catch (_: Exception) {}
        }
    }

    LaunchedEffect(lensFacing, previewView, lifecycleOwner) {
        val currentPreviewView = previewView ?: return@LaunchedEffect
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                val provider = cameraProviderFuture.get()
                cameraProvider = provider

                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = currentPreviewView.surfaceProvider
                }

                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(100)
                    .setTargetRotation(currentPreviewView.display.rotation)
                    .build()
                imageCapture = capture

                val cameraSelector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing)
                    .build()

                provider.unbindAll()
                provider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    capture
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, ContextCompat.getMainExecutor(context))
    }

    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(16.dp))
                .border(2.dp, CyanAccent, RoundedCornerShape(16.dp))
                .testTag("camera_viewfinder"),
            factory = { ctx ->
                PreviewView(ctx).apply {
                    // COMPATIBLE mode uses TextureView to eliminate BufferQueue abandoned crashes in Compose
                    implementationMode = PreviewView.ImplementationMode.PERFORMANCE
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                    previewView = this
                }
            },
            update = {
                // Do not rebind camera lifecycle here on recompositions
            }
        )

        // Accessibility crosshairs / framing reticle for visual assistance
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp)
        ) {
            val strokeWidth = 3.dp.toPx()
            val reticleColor = Color(0x8000E5FF)
            // Center target bounds
            drawRect(
                color = reticleColor,
                topLeft = Offset(size.width * 0.15f, size.height * 0.2f),
                size = Size(size.width * 0.7f, size.height * 0.5f),
                style = Stroke(width = strokeWidth)
            )
        }

        // Camera control bar overlay at bottom
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 24.dp, start = 16.dp, end = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Demo Image Option
                IconButton(
                    onClick = onDemoImageSelected,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .border(1.dp, CyanAccent, CircleShape)
                        .testTag("demo_scene_button")
                        .semantics { contentDescription = "Use Demo Image" }
                ) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = "Demo Image",
                        tint = CyanAccent
                    )
                }

                // Primary Capture Button (High Contrast, Large Target >= 64dp)
                Button(
                    onClick = {
                        val capture = imageCapture ?: return@Button
                        val outputFile = File.createTempFile("sahaaya_capture_", ".jpg", context.cacheDir)
                        val outputOptions = OutputFileOptions.Builder(outputFile).build()

                        // Save the camera's real JPEG output instead of converting the
                        // ImageProxy/YUV buffer directly to a Bitmap. This preserves the
                        // camera JPEG and avoids the pixelation/corruption seen in the
                        // previous ImageProxy.toBitmap() path.
                        capture.takePicture(
                            outputOptions,
                            cameraExecutor,
                            object : ImageCapture.OnImageSavedCallback {
                                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                    try {
                                        val bitmap = BitmapFactory.decodeFile(outputFile.absolutePath)
                                            ?: throw IllegalStateException("Captured JPEG could not be decoded")

                                        ContextCompat.getMainExecutor(context).execute {
                                            onImageCaptured(bitmap)
                                        }
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    } finally {
                                        outputFile.delete()
                                    }
                                }

                                override fun onError(exception: ImageCaptureException) {
                                    exception.printStackTrace()
                                    outputFile.delete()
                                }
                            }
                        )
                    },
                    enabled = !isCapturing,
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent,
                        contentColor = NavyDeep
                    ),
                    modifier = Modifier
                        .size(72.dp)
                        .testTag("capture_image_button")
                        .semantics { contentDescription = "Capture live photo for AI analysis" }
                ) {
                    if (isCapturing) {
                        CircularProgressIndicator(
                            color = NavyDeep,
                            modifier = Modifier.size(28.dp),
                            strokeWidth = 3.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Capture",
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                // Switch Camera Lens (Front/Back)
                IconButton(
                    onClick = {
                        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                            CameraSelector.LENS_FACING_FRONT
                        } else {
                            CameraSelector.LENS_FACING_BACK
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .border(1.dp, CyanAccent, CircleShape)
                        .testTag("flip_camera_button")
                        .semantics { contentDescription = "Switch Camera Facing" }
                ) {
                    Icon(
                        imageVector = Icons.Default.Cameraswitch,
                        contentDescription = "Switch Camera",
                        tint = CyanAccent
                    )
                }
            }
        }
    }
}
