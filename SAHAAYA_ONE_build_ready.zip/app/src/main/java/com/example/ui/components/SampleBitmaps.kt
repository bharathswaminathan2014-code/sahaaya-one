package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF

object SampleBitmaps {

    fun createDemoSceneBitmap(): Bitmap {
        val width = 640
        val height = 480
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background room
        val bgPaint = Paint().apply { color = Color.rgb(230, 235, 245) }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Floor
        val floorPaint = Paint().apply { color = Color.rgb(180, 160, 140) }
        canvas.drawRect(0f, 320f, width.toFloat(), height.toFloat(), floorPaint)

        // Table
        val tablePaint = Paint().apply { color = Color.rgb(100, 60, 30) }
        canvas.drawRoundRect(RectF(100f, 260f, 540f, 440f), 12f, 12f, tablePaint)

        // Coffee Mug on table
        val mugPaint = Paint().apply { color = Color.rgb(20, 120, 210) }
        canvas.drawRoundRect(RectF(160f, 220f, 240f, 310f), 8f, 8f, mugPaint)

        // Water Bottle
        val bottlePaint = Paint().apply { color = Color.rgb(50, 180, 120) }
        canvas.drawRoundRect(RectF(280f, 160f, 350f, 310f), 12f, 12f, bottlePaint)

        // Printed Signboard on wall
        val signPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRoundRect(RectF(140f, 40f, 500f, 140f), 8f, 8f, signPaint)
        val signBorder = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        canvas.drawRoundRect(RectF(140f, 40f, 500f, 140f), 8f, 8f, signBorder)

        // Text on signboard
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 34f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("CAUTION: WET FLOOR", 320f, 95f, textPaint)

        return bitmap
    }
}
