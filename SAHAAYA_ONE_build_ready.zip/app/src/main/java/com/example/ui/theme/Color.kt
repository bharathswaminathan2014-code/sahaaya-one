package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SAHAAYA ONE Branding & High Contrast Accessible Palette
val NavyDeep = Color(0xFF070D1E)
val NavySurface = Color(0xFF0F1B36)
val NavyCard = Color(0xFF17264C)
val NavyCardBorder = Color(0xFF2E467D)

val CyanAccent = Color(0xFF00E5FF)
val CyanGlow = Color(0xFF80F2FF)
val AmberAccent = Color(0xFFFFB703)
val AmberGlow = Color(0xFFFFD166)

val AlertRed = Color(0xFFFF334B)
val AlertRedDark = Color(0xFF8F1221)
val SuccessGreen = Color(0xFF00E676)

val TextHighContrast = Color(0xFFFFFFFF)
val TextMediumContrast = Color(0xFFD4DCF2)
val TextMuted = Color(0xFF90A1C8)

