package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuickPhrase
import com.example.ui.SahaayaViewModel
import com.example.ui.components.DemoStateBanner
import com.example.ui.components.SahaayaTopBar
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.TextHighContrast
import com.example.ui.theme.TextMediumContrast
import com.example.ui.theme.TextMuted

@Composable
fun CommunicateScreen(
    viewModel: SahaayaViewModel,
    onNavigateBack: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val preferences by viewModel.preferences.collectAsState()
    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsState()
    val communicateState by viewModel.communicateState.collectAsState()

    var customInputText by remember { mutableStateOf("") }
    var aiScenarioInput by remember { mutableStateOf("") }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            SahaayaTopBar(
                title = "COMMUNICATE (AAC & Speech)",
                currentProfile = preferences.selectedProfile,
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                isTtsSpeaking = isSpeaking,
                onStopTts = { viewModel.stopSpeaking() },
                onProfileClick = onProfileClick
            )
        },
        containerColor = NavyDeep,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            if (preferences.isDemoMode) {
                DemoStateBanner()
            }

            // Direct Type & Speak Box
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Type & Speak",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = customInputText,
                        onValueChange = { customInputText = it },
                        placeholder = { Text("Enter words to speak aloud...") },
                        trailingIcon = {
                            if (customInputText.isNotBlank()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = {
                                            viewModel.addCustomPhrase(customInputText.trim())
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Add,
                                            contentDescription = "Save to custom phrases",
                                            tint = AmberAccent
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            viewModel.speakPhrase(customInputText.trim())
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.VolumeUp,
                                            contentDescription = "Speak text",
                                            tint = CyanAccent
                                        )
                                    }
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = NavyCardBorder,
                            focusedTextColor = TextHighContrast,
                            unfocusedTextColor = TextHighContrast
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("communicate_custom_input")
                    )
                }
            }

            // AI Communication Assistant (Generate -> Review -> User Confirmation -> Speak)
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF64FFDA)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color(0xFF64FFDA),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AI Communication Assistant",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextHighContrast
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Need help phrasing what to say? Describe the context below. The app will generate a draft for your review.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMediumContrast)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = aiScenarioInput,
                        onValueChange = { aiScenarioInput = it },
                        placeholder = { Text("e.g. Tell the doctor my knee hurts") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF64FFDA),
                            unfocusedBorderColor = NavyCardBorder,
                            focusedTextColor = TextHighContrast,
                            unfocusedTextColor = TextHighContrast
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (aiScenarioInput.isNotBlank()) {
                                viewModel.requestAiCommunicationHelp(aiScenarioInput)
                            }
                        },
                        enabled = !communicateState.isGeneratingAiPhrase && aiScenarioInput.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF64FFDA),
                            contentColor = NavyDeep
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_assist_generate_button")
                    ) {
                        if (communicateState.isGeneratingAiPhrase) {
                            CircularProgressIndicator(
                                color = NavyDeep,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Drafting Phrasing...")
                        } else {
                            Text("Generate Suggestion", fontWeight = FontWeight.Bold)
                        }
                    }

                    // STRICT USER REVIEW & CONFIRMATION BOX
                    communicateState.aiGeneratedSuggestion?.let { suggestion ->
                        Spacer(modifier = Modifier.height(14.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(NavyCard, RoundedCornerShape(10.dp))
                                .border(1.5.dp, AmberAccent, RoundedCornerShape(10.dp))
                                .padding(14.dp)
                                .testTag("ai_suggestion_confirmation_box")
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Review Before Speaking",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = AmberAccent
                                        )
                                    )
                                    IconButton(
                                        onClick = { viewModel.dismissAiSuggestion() },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = TextMuted)
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = "\"$suggestion\"",
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        color = TextHighContrast,
                                        fontWeight = FontWeight.Medium
                                    )
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = {
                                        // User explicitly confirms before speech
                                        viewModel.confirmAndSpeakAiPhrase(suggestion)
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CyanAccent,
                                        contentColor = NavyDeep
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("confirm_and_speak_button")
                                        .semantics { contentDescription = "Confirm and speak: $suggestion" }
                                ) {
                                    Icon(Icons.Default.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Confirm & Speak Aloud", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Quick Phrases AAC Board
            Text(
                text = "Quick Assist Phrases (One-Tap Speak)",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextHighContrast
                )
            )

            // Standard AAC phrases
            val phrases = communicateState.quickPhrases
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                phrases.forEach { item ->
                    QuickPhraseItem(
                        phrase = item,
                        onClick = { viewModel.speakPhrase(item.text) }
                    )
                }
            }

            // Custom Saved Phrases
            if (communicateState.customPhrases.isNotEmpty()) {
                Text(
                    text = "My Custom Saved Phrases",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = AmberAccent
                    )
                )
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    communicateState.customPhrases.forEach { phrase ->
                        CustomPhraseItem(
                            text = phrase,
                            onClick = { viewModel.speakPhrase(phrase) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun QuickPhraseItem(
    phrase: QuickPhrase,
    onClick: () -> Unit
) {
    val isUrgent = phrase.category == "Urgent"
    val borderColor = if (isUrgent) AlertRed else CyanAccent

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("quick_phrase_${phrase.id}")
            .semantics { contentDescription = "Speak phrase: ${phrase.text}" }
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = phrase.text,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextHighContrast
                    )
                )
                Text(
                    text = phrase.category,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (isUrgent) AlertRed else CyanAccent
                    )
                )
            }

            Icon(
                imageVector = Icons.Default.VolumeUp,
                contentDescription = null,
                tint = if (isUrgent) AlertRed else CyanAccent,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
private fun CustomPhraseItem(
    text: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, AmberAccent),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .semantics { contentDescription = "Speak custom phrase: $text" }
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Medium,
                    color = TextHighContrast
                ),
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = Icons.Default.VolumeUp,
                contentDescription = null,
                tint = AmberAccent,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
