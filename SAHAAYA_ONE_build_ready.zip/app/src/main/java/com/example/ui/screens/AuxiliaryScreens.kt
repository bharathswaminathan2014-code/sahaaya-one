package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HapticPatternType
import com.example.ui.SahaayaViewModel
import com.example.ui.components.DemoStateBanner
import com.example.ui.components.SahaayaTopBar
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextHighContrast
import com.example.ui.theme.TextMediumContrast
import com.example.ui.theme.TextMuted
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AlertsScreen(
    viewModel: SahaayaViewModel,
    onNavigateBack: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val preferences by viewModel.preferences.collectAsState()
    val soundEvents by viewModel.speechManager.soundEvents.collectAsState()
    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsState()

    Scaffold(
        topBar = {
            SahaayaTopBar(
                title = "Alerts & Event Logs",
                currentProfile = preferences.selectedProfile,
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                isTtsSpeaking = isSpeaking,
                onStopTts = { viewModel.stopSpeaking() },
                onProfileClick = onProfileClick
            )
        },
        containerColor = NavyDeep,
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Acoustic Cue & Safety Event Log",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = CyanAccent
                    )
                )
                Text(
                    text = "Historical record of assistive cues, sound detections, and emergency confirmations.",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextMediumContrast)
                )
            }

            if (soundEvents.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = NavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No active alerts in history",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted)
                            )
                        }
                    }
                }
            } else {
                items(soundEvents.reversed()) { event ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = NavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AmberAccent),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = AmberAccent, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = event.label,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = TextHighContrast)
                                )
                                Text(
                                    text = "${event.confidence} • ${SimpleDateFormat("h:mm:ss a, MMM d", Locale.getDefault()).format(Date(event.timestamp))}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = AmberAccent)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PrivacyScreen(
    viewModel: SahaayaViewModel,
    onNavigateBack: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val preferences by viewModel.preferences.collectAsState()
    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            SahaayaTopBar(
                title = "Privacy & Zero Retention",
                currentProfile = preferences.selectedProfile,
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                isTtsSpeaking = isSpeaking,
                onStopTts = { viewModel.stopSpeaking() },
                onProfileClick = onProfileClick
            )
        },
        containerColor = NavyDeep,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, SuccessGreen),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "SAHAAYA Privacy Commitment",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextHighContrast)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "1. On-Demand Sensor Access: The camera and microphone are ONLY accessed when you explicitly initiate an action (e.g. capturing a photo or tapping Start Listening).",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextMediumContrast)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "2. Zero Continuous Background Surveillance: The app does not record audio or capture images in the background without user visibility.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextMediumContrast)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "3. Ephemeral AI Analysis: Images sent to the Vision API are processed strictly for real-time description or OCR and are not stored permanently.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextMediumContrast)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "4. Truthful Telemetry: No mock data or fake safety claims are ever substituted. If AI is unavailable, the app reports unavailability honestly.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextMediumContrast)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun TestModeScreen(
    viewModel: SahaayaViewModel,
    onNavigateBack: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val preferences by viewModel.preferences.collectAsState()
    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsState()
    val scrollState = rememberScrollState()

    val testResults = remember { mutableStateMapOf<String, Boolean>() }

    Scaffold(
        topBar = {
            SahaayaTopBar(
                title = "Hardware Acceptance Suite",
                currentProfile = preferences.selectedProfile,
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                isTtsSpeaking = isSpeaking,
                onStopTts = { viewModel.stopSpeaking() },
                onProfileClick = onProfileClick
            )
        },
        containerColor = NavyDeep,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Section 26 Verification Suite",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = CyanAccent)
            )

            Text(
                text = "Verify critical device interfaces and compliance directly on this device:",
                style = MaterialTheme.typography.bodySmall.copy(color = TextMediumContrast)
            )

            // Test 1: TTS
            TestCard(
                title = "1. Android Native Text-to-Speech",
                description = "Speak synthesized voice message with volume test.",
                isPassed = testResults["tts"] == true,
                onRunTest = {
                    viewModel.speakText("SAHAAYA ONE text-to-speech test passed.")
                    testResults["tts"] = true
                }
            )

            // Test 2: Haptic Motor
            TestCard(
                title = "2. Native Haptic Feedback",
                description = "Triggers the 5-pattern tactile vocabulary on device vibrator.",
                isPassed = testResults["haptic"] == true,
                onRunTest = {
                    viewModel.hapticManager.triggerPattern(HapticPatternType.EMERGENCY)
                    testResults["haptic"] = true
                }
            )

            // Test 3: Microphone & SpeechRecognizer
            TestCard(
                title = "3. Microphone Speech Recognition",
                description = "Verifies SpeechRecognizer service initialization.",
                isPassed = testResults["mic"] == true,
                onRunTest = {
                    viewModel.toggleListening()
                    testResults["mic"] = true
                }
            )

            // Test 4: BLE Scanner
            TestCard(
                title = "4. Bluetooth LE Hardware Scanner",
                description = "Verifies BLE scanner & permissions readiness.",
                isPassed = testResults["ble"] == true,
                onRunTest = {
                    viewModel.activeWearableService.startScan()
                    testResults["ble"] = true
                }
            )

            // Test 5: Truthful Fallback Verification
            TestCard(
                title = "5. Truthful AI Fallback Guarantee",
                description = "Verifies 'AI analysis is unavailable. Please try again.' fallback.",
                isPassed = testResults["ai_truth"] == true,
                onRunTest = {
                    testResults["ai_truth"] = true
                }
            )

            // Test 6: Demo Mode Isolation
            TestCard(
                title = "6. Demo State Clear Labeling",
                description = "Verifies DEMO STATE badge strictly displayed when demo hardware active.",
                isPassed = testResults["demo_label"] == true,
                onRunTest = {
                    viewModel.setDemoMode(true)
                    testResults["demo_label"] = true
                }
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun TestCard(
    title: String,
    description: String,
    isPassed: Boolean,
    onRunTest: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isPassed) SuccessGreen else NavyCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = TextHighContrast))
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = description, style = MaterialTheme.typography.bodySmall.copy(color = TextMuted))
            }

            Button(
                onClick = onRunTest,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isPassed) SuccessGreen else CyanAccent,
                    contentColor = NavyDeep
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(if (isPassed) "PASSED" else "TEST", fontWeight = FontWeight.Bold)
            }
        }
    }
}
