package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AccessibilityProfile
import com.example.data.model.CommunicationState
import com.example.data.model.EmergencyState
import com.example.data.model.EmergencyStatus
import com.example.data.model.HapticPatternType
import com.example.data.model.HearingState
import com.example.data.model.QuickPhrase
import com.example.data.model.SeeAnalysisState
import com.example.data.model.SeeMode
import com.example.data.model.UserPreferences
import com.example.data.model.WearableTelemetry
import com.example.service.AdaptiveOutputRouter
import com.example.service.BluetoothWearableService
import com.example.service.DemoWearableService
import com.example.service.EmergencyManager
import com.example.service.GeminiVisionService
import com.example.service.HapticManager
import com.example.service.SpeechRecognitionManager
import com.example.service.TextToSpeechManager
import com.example.service.WearableService
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AssistantChatMessage(
    val id: String,
    val sender: String, // "User" or "SAHAAYA"
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

class SahaayaViewModel(application: Application) : AndroidViewModel(application) {

    // Managers & Services
    val hapticManager = HapticManager(application)
    val ttsManager = TextToSpeechManager(application)
    val outputRouter = AdaptiveOutputRouter(ttsManager, hapticManager)
    val speechManager = SpeechRecognitionManager(application, viewModelScope)
    val geminiService = GeminiVisionService()
    val emergencyManager = EmergencyManager(application, viewModelScope, hapticManager)
    private val appPrefs = application.getSharedPreferences("sahaaya_settings", android.content.Context.MODE_PRIVATE)

    private val demoWearable = DemoWearableService(viewModelScope)
    private val bleWearable = BluetoothWearableService(application, viewModelScope)

    // User Preferences State
    private val _preferences = MutableStateFlow(UserPreferences())
    val preferences: StateFlow<UserPreferences> = _preferences.asStateFlow()

    // Wearable Service selection based on Demo Mode
    val activeWearableService: WearableService
        get() = if (_preferences.value.isDemoMode) demoWearable else bleWearable

    // SEE State
    private val _seeState = MutableStateFlow(SeeAnalysisState())
    val seeState: StateFlow<SeeAnalysisState> = _seeState.asStateFlow()

    // Band button -> SEE camera capture requests (ignored when the SEE camera is not on screen)
    private val _wearableCaptureRequests = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val wearableCaptureRequests: SharedFlow<Unit> = _wearableCaptureRequests.asSharedFlow()

    // HEAR State (from speechManager)
    val hearingState: StateFlow<HearingState> = speechManager.liveTranscript.let {
        // Collect aggregated hearing state
        MutableStateFlow(HearingState())
    }

    // COMMUNICATE State
    private val _communicateState = MutableStateFlow(CommunicationState())
    val communicateState: StateFlow<CommunicationState> = _communicateState.asStateFlow()

    // ASSISTANT State
    private val _assistantMessages = MutableStateFlow(
        listOf(
            AssistantChatMessage(
                id = "welcome",
                sender = "SAHAAYA",
                message = "Hello, I am your SAHAAYA ONE accessibility companion. You can ask me to describe your surroundings, read printed text, listen to nearby speech, or assist in communication."
            )
        )
    )
    val assistantMessages: StateFlow<List<AssistantChatMessage>> = _assistantMessages.asStateFlow()

    private val _isAssistantThinking = MutableStateFlow(false)
    val isAssistantThinking: StateFlow<Boolean> = _isAssistantThinking.asStateFlow()

    init {
        // Initialize backend URL if configured
        geminiService.updateBackendUrl(_preferences.value.backendUrl)
        geminiService.updateApiKey(getGeminiApiKey())
        startWearableBridge()
    }

    // -------------------------------------------------------------
    // ACCESSIBILITY PROFILE & PREFERENCES
    // -------------------------------------------------------------
    fun selectProfile(profile: AccessibilityProfile) {
        _preferences.value = _preferences.value.copy(selectedProfile = profile)
        outputRouter.route(
            profile = profile,
            task = AdaptiveOutputRouter.TaskType.GENERAL_NOTIFICATION,
            content = "${profile.title} profile activated.",
            customHaptic = HapticPatternType.NOTIFICATION,
            intensity = _preferences.value.hapticIntensity
        )
    }

    fun updateTtsSettings(rate: Float, pitch: Float) {
        _preferences.value = _preferences.value.copy(ttsRate = rate, ttsPitch = pitch)
        ttsManager.setSpeechRate(rate)
        ttsManager.setPitch(pitch)
    }

    fun updateHapticIntensity(intensity: Float) {
        _preferences.value = _preferences.value.copy(hapticIntensity = intensity)
        hapticManager.triggerPattern(HapticPatternType.NOTIFICATION, intensity)
    }

    fun setHighContrast(enabled: Boolean) {
        _preferences.value = _preferences.value.copy(highContrastEnabled = enabled)
    }

    fun setDemoMode(enabled: Boolean) {
        _preferences.value = _preferences.value.copy(isDemoMode = enabled)
        hapticManager.triggerPattern(HapticPatternType.ACTIVITY, _preferences.value.hapticIntensity)
    }

    fun setEmergencyContact(name: String, phone: String) {
        _preferences.value = _preferences.value.copy(
            emergencyContactName = name,
            emergencyContactPhone = phone
        )
    }

    fun setBackendUrl(url: String) {
        _preferences.value = _preferences.value.copy(backendUrl = url)
        geminiService.updateBackendUrl(url)
    }

    // -------------------------------------------------------------
    // WEARABLE BAND BRIDGE
    // -------------------------------------------------------------
    private fun startWearableBridge() {
        // Band button: 1 = single press (describe), 2 = double press (read text), 3 = long press (emergency request)
        viewModelScope.launch {
            bleWearable.buttonEvents.collect { code ->
                when (code) {
                    1 -> {
                        setSeeMode(SeeMode.Describe)
                        _wearableCaptureRequests.tryEmit(Unit)
                    }
                    2 -> {
                        setSeeMode(SeeMode.Read)
                        _wearableCaptureRequests.tryEmit(Unit)
                    }
                    3 -> {
                        emergencyManager.initiateEmergencyRequest()
                        ttsManager.speak("Emergency request started. Please confirm on the phone.")
                    }
                }
            }
        }

        // Vibrate the band when a SEE result (or error) arrives
        viewModelScope.launch {
            var wasLoading = false
            seeState.collect { state ->
                if (wasLoading && !state.isLoading) {
                    bleWearable.sendHapticPattern(
                        if (state.errorMessage != null) 3 else 2,
                        _preferences.value.hapticIntensity
                    )
                }
                wasLoading = state.isLoading
            }
        }

        // Vibrate the band when an emergency request or countdown starts
        viewModelScope.launch {
            var lastStatus = EmergencyStatus.IDLE
            emergencyManager.state.collect { emergency ->
                if (emergency.status != lastStatus) {
                    if (emergency.status == EmergencyStatus.CONFIRMATION_REQUIRED ||
                        emergency.status == EmergencyStatus.COUNTDOWN_ACTIVE
                    ) {
                        bleWearable.sendHapticPattern(4, _preferences.value.hapticIntensity)
                    }
                    lastStatus = emergency.status
                }
            }
        }
    }

    fun getGeminiApiKey(): String = appPrefs.getString("gemini_api_key", "") ?: ""

    fun setGeminiApiKey(key: String) {
        val clean = key.trim()
        appPrefs.edit().putString("gemini_api_key", clean).apply()
        geminiService.updateApiKey(clean)
    }

    // -------------------------------------------------------------
    // SEE (DESCRIBE, READ, ASK)
    // -------------------------------------------------------------
    fun setSeeMode(mode: SeeMode) {
        _seeState.value = _seeState.value.copy(mode = mode, errorMessage = null)
        hapticManager.triggerPattern(HapticPatternType.NOTIFICATION, _preferences.value.hapticIntensity)
    }

    fun setCapturedBitmap(bitmap: Bitmap?, isDemo: Boolean = false) {
        _seeState.value = _seeState.value.copy(
            capturedBitmap = bitmap,
            isDemoImage = isDemo,
            resultText = null,
            extractedText = null,
            errorMessage = null
        )
        if (bitmap != null) {
            hapticManager.triggerPattern(HapticPatternType.ACTIVITY, _preferences.value.hapticIntensity)
        }
    }

    fun setUserQuestion(question: String) {
        _seeState.value = _seeState.value.copy(userQuestion = question)
    }

    fun analyzeCapturedImage() {
        val bitmap = _seeState.value.capturedBitmap ?: run {
            _seeState.value = _seeState.value.copy(errorMessage = "Please capture or select an image first.")
            return
        }

        _seeState.value = _seeState.value.copy(isLoading = true, errorMessage = null, resultText = null)

        viewModelScope.launch {
            when (_seeState.value.mode) {
                is SeeMode.Describe -> {
                    when (val res = geminiService.describeScene(bitmap)) {
                        is GeminiVisionService.VisionResult.Success -> {
                            _seeState.value = _seeState.value.copy(
                                isLoading = false,
                                resultText = res.text
                            )
                            outputRouter.route(
                                profile = _preferences.value.selectedProfile,
                                task = AdaptiveOutputRouter.TaskType.SEE_DESCRIPTION,
                                content = res.text,
                                intensity = _preferences.value.hapticIntensity
                            )
                        }
                        is GeminiVisionService.VisionResult.Error -> {
                            _seeState.value = _seeState.value.copy(
                                isLoading = false,
                                errorMessage = res.message
                            )
                            outputRouter.route(
                                profile = _preferences.value.selectedProfile,
                                task = AdaptiveOutputRouter.TaskType.GENERAL_NOTIFICATION,
                                content = res.message,
                                customHaptic = HapticPatternType.IMPORTANT_ALERT,
                                intensity = _preferences.value.hapticIntensity
                            )
                        }
                    }
                }
                is SeeMode.Read -> {
                    when (val res = geminiService.readText(bitmap)) {
                        is GeminiVisionService.VisionResult.Success -> {
                            _seeState.value = _seeState.value.copy(
                                isLoading = false,
                                extractedText = res.text,
                                resultText = res.text
                            )
                            outputRouter.route(
                                profile = _preferences.value.selectedProfile,
                                task = AdaptiveOutputRouter.TaskType.SEE_OCR_TEXT,
                                content = res.text,
                                intensity = _preferences.value.hapticIntensity
                            )
                        }
                        is GeminiVisionService.VisionResult.Error -> {
                            _seeState.value = _seeState.value.copy(
                                isLoading = false,
                                errorMessage = res.message
                            )
                        }
                    }
                }
                is SeeMode.Ask -> {
                    val question = _seeState.value.userQuestion.ifBlank { "What is in this image?" }
                    when (val res = geminiService.askImageQuestion(bitmap, question)) {
                        is GeminiVisionService.VisionResult.Success -> {
                            _seeState.value = _seeState.value.copy(
                                isLoading = false,
                                resultText = res.text
                            )
                            outputRouter.route(
                                profile = _preferences.value.selectedProfile,
                                task = AdaptiveOutputRouter.TaskType.SEE_DESCRIPTION,
                                content = res.text,
                                intensity = _preferences.value.hapticIntensity
                            )
                        }
                        is GeminiVisionService.VisionResult.Error -> {
                            _seeState.value = _seeState.value.copy(
                                isLoading = false,
                                errorMessage = res.message
                            )
                        }
                    }
                }
            }
        }
    }

    fun speakText(text: String) {
        ttsManager.speak(text)
    }

    fun stopSpeaking() {
        ttsManager.stop()
    }

    // -------------------------------------------------------------
    // HEAR (SPEECH TO TEXT & SOUNDS)
    // -------------------------------------------------------------
    fun toggleListening() {
        if (speechManager.isListening.value) {
            speechManager.stopListening()
            hapticManager.triggerPattern(HapticPatternType.NOTIFICATION, _preferences.value.hapticIntensity)
        } else {
            speechManager.startListening()
            hapticManager.triggerPattern(HapticPatternType.ACTIVITY, _preferences.value.hapticIntensity)
        }
    }

    fun clearHearingHistory() {
        speechManager.clearHistory()
    }

    // -------------------------------------------------------------
    // COMMUNICATE (AAC & CONFIRMED AI SPEECH)
    // -------------------------------------------------------------
    fun speakPhrase(phrase: String) {
        // Direct phrases (e.g. Quick Phrases) chosen directly by the user are spoken
        outputRouter.route(
            profile = _preferences.value.selectedProfile,
            task = AdaptiveOutputRouter.TaskType.COMMUNICATION_SPEAK,
            content = phrase,
            forceSpeech = true,
            intensity = _preferences.value.hapticIntensity
        )
    }

    fun addCustomPhrase(phrase: String) {
        if (phrase.isBlank()) return
        val current = _communicateState.value.customPhrases.toMutableList()
        if (!current.contains(phrase)) {
            current.add(phrase)
            _communicateState.value = _communicateState.value.copy(customPhrases = current)
            hapticManager.triggerPattern(HapticPatternType.NOTIFICATION, _preferences.value.hapticIntensity)
        }
    }

    fun requestAiCommunicationHelp(contextScenario: String) {
        _communicateState.value = _communicateState.value.copy(
            isGeneratingAiPhrase = true,
            isConfirmedForSpeech = false,
            errorMessage = null
        )

        viewModelScope.launch {
            val suggestions = geminiService.generateCommunicationSuggestions(contextScenario)
            if (suggestions.isNotEmpty()) {
                _communicateState.value = _communicateState.value.copy(
                    isGeneratingAiPhrase = false,
                    aiGeneratedSuggestion = suggestions.firstOrNull(),
                    isConfirmedForSpeech = false
                )
                hapticManager.triggerPattern(HapticPatternType.ACTIVITY, _preferences.value.hapticIntensity)
            } else {
                _communicateState.value = _communicateState.value.copy(
                    isGeneratingAiPhrase = false,
                    errorMessage = "AI assistance is unavailable. Please try again."
                )
            }
        }
    }

    fun confirmAndSpeakAiPhrase(phrase: String) {
        // STRICT SPEC RULE: NEVER automatically speak AI-generated communication without user confirmation.
        _communicateState.value = _communicateState.value.copy(isConfirmedForSpeech = true)
        ttsManager.speak(phrase)
        hapticManager.triggerPattern(HapticPatternType.NOTIFICATION, _preferences.value.hapticIntensity)
    }

    fun dismissAiSuggestion() {
        _communicateState.value = _communicateState.value.copy(
            aiGeneratedSuggestion = null,
            isConfirmedForSpeech = false
        )
    }

    // -------------------------------------------------------------
    // AI ASSISTANT
    // -------------------------------------------------------------
    fun sendAssistantMessage(prompt: String) {
        if (prompt.isBlank()) return
        val userMsg = AssistantChatMessage(
            id = System.currentTimeMillis().toString(),
            sender = "User",
            message = prompt
        )
        _assistantMessages.value = _assistantMessages.value + userMsg
        _isAssistantThinking.value = true

        viewModelScope.launch {
            val replyText = when (val res = geminiService.assistantQuery(prompt)) {
                is GeminiVisionService.VisionResult.Success -> res.text
                is GeminiVisionService.VisionResult.Error -> "AI analysis is unavailable. Please try again."
            }

            val botMsg = AssistantChatMessage(
                id = (System.currentTimeMillis() + 1).toString(),
                sender = "SAHAAYA",
                message = replyText
            )
            _assistantMessages.value = _assistantMessages.value + botMsg
            _isAssistantThinking.value = false

            outputRouter.route(
                profile = _preferences.value.selectedProfile,
                task = AdaptiveOutputRouter.TaskType.ASSISTANT_RESPONSE,
                content = replyText,
                intensity = _preferences.value.hapticIntensity
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
        speechManager.stopListening()
        hapticManager.stop()
    }
}
