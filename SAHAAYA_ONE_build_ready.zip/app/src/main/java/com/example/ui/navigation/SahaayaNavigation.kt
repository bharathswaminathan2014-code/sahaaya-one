package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.SahaayaViewModel
import com.example.ui.screens.AlertsScreen
import com.example.ui.screens.AssistantScreen
import com.example.ui.screens.CommunicateScreen
import com.example.ui.screens.EmergencyScreen
import com.example.ui.screens.HearScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PrivacyScreen
import com.example.ui.screens.ProfileSelectionScreen
import com.example.ui.screens.SeeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.TestModeScreen
import com.example.ui.screens.WearableScreen

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val PROFILE_SELECT = "profile_select"
    const val HOME = "home"
    const val SEE = "see"
    const val HEAR = "hear"
    const val COMMUNICATE = "communicate"
    const val ASSISTANT = "assistant"
    const val WEARABLE = "wearable"
    const val EMERGENCY = "emergency"
    const val ALERTS = "alerts"
    const val SETTINGS = "settings"
    const val PRIVACY = "privacy"
    const val TEST_MODE = "test_mode"
}

@Composable
fun SahaayaNavGraph(
    viewModel: SahaayaViewModel,
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController()
) {
    val preferences by viewModel.preferences.collectAsState()
    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsState()

    NavHost(
        navController = navController,
        startDestination = Routes.SPLASH,
        modifier = modifier
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onContinue = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.ONBOARDING) {
            OnboardingScreen(
                onNavigateToProfile = { navController.navigate(Routes.PROFILE_SELECT) },
                onNavigateToHome = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.ONBOARDING) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.PROFILE_SELECT) {
            ProfileSelectionScreen(
                currentProfile = preferences.selectedProfile,
                onSelectProfile = { viewModel.selectProfile(it) },
                onDone = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.PROFILE_SELECT) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.HOME) {
            HomeScreen(
                currentProfile = preferences.selectedProfile,
                isDemoMode = preferences.isDemoMode,
                onNavigateToSee = { navController.navigate(Routes.SEE) },
                onNavigateToHear = { navController.navigate(Routes.HEAR) },
                onNavigateToCommunicate = { navController.navigate(Routes.COMMUNICATE) },
                onNavigateToAssistant = { navController.navigate(Routes.ASSISTANT) },
                onNavigateToWearable = { navController.navigate(Routes.WEARABLE) },
                onNavigateToEmergency = { navController.navigate(Routes.EMERGENCY) },
                onNavigateToSettings = { navController.navigate(Routes.SETTINGS) },
                onNavigateToAlerts = { navController.navigate(Routes.ALERTS) },
                onNavigateToPrivacy = { navController.navigate(Routes.PRIVACY) },
                onNavigateToTestMode = { navController.navigate(Routes.TEST_MODE) },
                onProfileClick = { navController.navigate(Routes.PROFILE_SELECT) },
                isTtsSpeaking = isSpeaking,
                onStopTts = { viewModel.stopSpeaking() }
            )
        }

        composable(Routes.SEE) {
            SeeScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onProfileClick = { navController.navigate(Routes.PROFILE_SELECT) }
            )
        }

        composable(Routes.HEAR) {
            HearScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onProfileClick = { navController.navigate(Routes.PROFILE_SELECT) }
            )
        }

        composable(Routes.COMMUNICATE) {
            CommunicateScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onProfileClick = { navController.navigate(Routes.PROFILE_SELECT) }
            )
        }

        composable(Routes.ASSISTANT) {
            AssistantScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToSee = { navController.navigate(Routes.SEE) },
                onNavigateToHear = { navController.navigate(Routes.HEAR) },
                onNavigateToCommunicate = { navController.navigate(Routes.COMMUNICATE) },
                onProfileClick = { navController.navigate(Routes.PROFILE_SELECT) }
            )
        }

        composable(Routes.WEARABLE) {
            WearableScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onProfileClick = { navController.navigate(Routes.PROFILE_SELECT) }
            )
        }

        composable(Routes.EMERGENCY) {
            EmergencyScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToSettings = { navController.navigate(Routes.SETTINGS) },
                onProfileClick = { navController.navigate(Routes.PROFILE_SELECT) }
            )
        }

        composable(Routes.ALERTS) {
            AlertsScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onProfileClick = { navController.navigate(Routes.PROFILE_SELECT) }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToProfileSelection = { navController.navigate(Routes.PROFILE_SELECT) },
                onProfileClick = { navController.navigate(Routes.PROFILE_SELECT) }
            )
        }

        composable(Routes.PRIVACY) {
            PrivacyScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onProfileClick = { navController.navigate(Routes.PROFILE_SELECT) }
            )
        }

        composable(Routes.TEST_MODE) {
            TestModeScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onProfileClick = { navController.navigate(Routes.PROFILE_SELECT) }
            )
        }
    }
}
