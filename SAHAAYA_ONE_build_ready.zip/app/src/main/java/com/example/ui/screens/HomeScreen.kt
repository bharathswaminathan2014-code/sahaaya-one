package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccessibilityProfile
import com.example.ui.components.DemoStateBanner
import com.example.ui.components.SahaayaTopBar
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.TextHighContrast
import com.example.ui.theme.TextMediumContrast
import com.example.ui.theme.TextMuted

@Composable
fun HomeScreen(
    currentProfile: AccessibilityProfile,
    isDemoMode: Boolean,
    onNavigateToSee: () -> Unit,
    onNavigateToHear: () -> Unit,
    onNavigateToCommunicate: () -> Unit,
    onNavigateToAssistant: () -> Unit,
    onNavigateToWearable: () -> Unit,
    onNavigateToEmergency: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToAlerts: () -> Unit,
    onNavigateToPrivacy: () -> Unit,
    onNavigateToTestMode: () -> Unit,
    onProfileClick: () -> Unit,
    isTtsSpeaking: Boolean,
    onStopTts: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            SahaayaTopBar(
                title = "SAHAAYA ONE",
                currentProfile = currentProfile,
                canNavigateBack = false,
                onNavigateBack = {},
                isTtsSpeaking = isTtsSpeaking,
                onStopTts = onStopTts,
                onProfileClick = onProfileClick
            )
        },
        containerColor = NavyDeep,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            if (isDemoMode) {
                DemoStateBanner()
            }

            // PRIMARY PILLARS: SEE, HEAR, COMMUNICATE
            Text(
                text = "Primary Accessibility Pillars",
                style = MaterialTheme.typography.titleSmall.copy(
                    color = CyanAccent,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )

            // SEE CARD
            PrimaryPillarCard(
                title = "SEE",
                subtitle = "Scene Description • Text OCR • Visual Inquiries",
                icon = Icons.Default.Visibility,
                accentColor = CyanAccent,
                onClick = onNavigateToSee,
                testTag = "home_card_see"
            )

            // HEAR CARD
            PrimaryPillarCard(
                title = "HEAR",
                subtitle = "Live Speech-to-Text • Qualified Acoustic Cues",
                icon = Icons.Default.Hearing,
                accentColor = AmberAccent,
                onClick = onNavigateToHear,
                testTag = "home_card_hear"
            )

            // COMMUNICATE CARD
            PrimaryPillarCard(
                title = "COMMUNICATE",
                subtitle = "AAC Quick Phrases • AI Suggestions • Confirmed Speech",
                icon = Icons.Default.RecordVoiceOver,
                accentColor = Color(0xFF64FFDA),
                onClick = onNavigateToCommunicate,
                testTag = "home_card_communicate"
            )

            Spacer(modifier = Modifier.height(8.dp))

            // SECONDARY FUNCTIONS
            Text(
                text = "Companion Tools",
                style = MaterialTheme.typography.titleSmall.copy(
                    color = TextMediumContrast,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )

            // 2-column or grid of companion actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SecondaryToolCard(
                    title = "AI Assistant",
                    icon = Icons.Default.AutoAwesome,
                    color = CyanAccent,
                    onClick = onNavigateToAssistant,
                    modifier = Modifier.weight(1f),
                    testTag = "home_tool_assistant"
                )
                SecondaryToolCard(
                    title = "Wearable",
                    icon = Icons.Default.Watch,
                    color = AmberAccent,
                    onClick = onNavigateToWearable,
                    modifier = Modifier.weight(1f),
                    testTag = "home_tool_wearable"
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SecondaryToolCard(
                    title = "Emergency",
                    icon = Icons.Default.Warning,
                    color = AlertRed,
                    onClick = onNavigateToEmergency,
                    modifier = Modifier.weight(1f),
                    testTag = "home_tool_emergency"
                )
                SecondaryToolCard(
                    title = "Alerts Log",
                    icon = Icons.Default.Notifications,
                    color = Color(0xFF80D8FF),
                    onClick = onNavigateToAlerts,
                    modifier = Modifier.weight(1f),
                    testTag = "home_tool_alerts"
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SecondaryToolCard(
                    title = "Settings",
                    icon = Icons.Default.Settings,
                    color = TextHighContrast,
                    onClick = onNavigateToSettings,
                    modifier = Modifier.weight(1f),
                    testTag = "home_tool_settings"
                )
                SecondaryToolCard(
                    title = "Test Mode",
                    icon = Icons.Default.Build,
                    color = Color(0xFFB388FF),
                    onClick = onNavigateToTestMode,
                    modifier = Modifier.weight(1f),
                    testTag = "home_tool_test_mode"
                )
            }

            SecondaryToolCard(
                title = "Privacy Policy & Zero Retention Pledge",
                icon = Icons.Default.Security,
                color = TextMediumContrast,
                onClick = onNavigateToPrivacy,
                modifier = Modifier.fillMaxWidth(),
                testTag = "home_tool_privacy"
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PrimaryPillarCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, accentColor),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag)
            .semantics { contentDescription = "Open $title: $subtitle" }
    ) {
        Row(
            modifier = Modifier
                .padding(18.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(30.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = TextHighContrast,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextMediumContrast,
                        lineHeight = 16.sp
                    )
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
private fun SecondaryToolCard(
    title: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
            .semantics { contentDescription = title }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextHighContrast
                )
            )
        }
    }
}
