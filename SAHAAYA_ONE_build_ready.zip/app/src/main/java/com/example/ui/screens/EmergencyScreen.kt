package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EmergencyStatus
import com.example.ui.SahaayaViewModel
import com.example.ui.components.DemoStateBanner
import com.example.ui.components.SahaayaTopBar
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AlertRedDark
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextHighContrast
import com.example.ui.theme.TextMediumContrast
import com.example.ui.theme.TextMuted

@Composable
fun EmergencyScreen(
    viewModel: SahaayaViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val preferences by viewModel.preferences.collectAsState()
    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsState()
    val emergencyState by viewModel.emergencyManager.state.collectAsState()

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            SahaayaTopBar(
                title = "Emergency Assistance",
                currentProfile = preferences.selectedProfile,
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                isTtsSpeaking = isSpeaking,
                onStopTts = { viewModel.stopSpeaking() },
                onProfileClick = onProfileClick
            )
        },
        containerColor = NavyDeep,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            if (preferences.isDemoMode) {
                DemoStateBanner()
            }

            // Emergency Notice Card
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, AlertRed),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = AlertRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Configured Contact: ${preferences.emergencyContactName} (${preferences.emergencyContactPhone})",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextHighContrast)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Main Tactile Emergency Action Trigger
            when (emergencyState.status) {
                EmergencyStatus.IDLE, EmergencyStatus.CANCELLED -> {
                    Text(
                        text = "Press below to request emergency assistance. A 5-second countdown with a cancellation window will begin.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = TextMediumContrast,
                            textAlign = TextAlign.Center
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.emergencyManager.initiateEmergencyRequest() },
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AlertRed,
                            contentColor = TextHighContrast
                        ),
                        modifier = Modifier
                            .size(160.dp)
                            .testTag("emergency_trigger_button")
                            .semantics { contentDescription = "Emergency Assistance Button. Press to initiate." }
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "EMERGENCY",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                )
                            )
                        }
                    }
                }

                EmergencyStatus.CONFIRMATION_REQUIRED -> {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = NavySurface),
                        border = androidx.compose.foundation.BorderStroke(2.dp, AlertRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Confirm Emergency Request?",
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AlertRed
                                ),
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "This will dispatch an urgent notification and dial your configured contact: ${preferences.emergencyContactPhone}.",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = TextMediumContrast,
                                    textAlign = TextAlign.Center
                                )
                            )

                            Spacer(modifier = Modifier.height(20.dp))

                            Button(
                                onClick = {
                                    viewModel.emergencyManager.confirmAndStartCountdown(preferences.emergencyContactPhone)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = AlertRed, contentColor = TextHighContrast),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("confirm_emergency_step_button")
                            ) {
                                Text("CONFIRM & START 5s DISPATCH", fontWeight = FontWeight.Bold)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedButton(
                                onClick = { viewModel.emergencyManager.cancelEmergency() },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextHighContrast),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("abort_emergency_button")
                            ) {
                                Text("Cancel")
                            }
                        }
                    }
                }

                EmergencyStatus.COUNTDOWN_ACTIVE -> {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = AlertRedDark),
                        border = androidx.compose.foundation.BorderStroke(2.dp, AlertRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Dispatching in ${emergencyState.countdownRemainingSeconds}s",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = TextHighContrast
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Tap CANCEL immediately to abort request.",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextHighContrast)
                            )

                            Spacer(modifier = Modifier.height(20.dp))

                            Button(
                                onClick = { viewModel.emergencyManager.cancelEmergency() },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = TextHighContrast, contentColor = AlertRedDark),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("emergency_countdown_cancel_button")
                            ) {
                                Icon(Icons.Default.Cancel, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("CANCEL EMERGENCY NOW", fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }

                EmergencyStatus.CONFIRMED -> {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = NavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, SuccessGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Emergency Action Requested",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SuccessGreen
                                )
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = emergencyState.statusMessage,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = TextHighContrast,
                                    textAlign = TextAlign.Center
                                ),
                                modifier = Modifier.testTag("emergency_truthful_status_message")
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { viewModel.emergencyManager.reset() },
                                colors = ButtonDefaults.buttonColors(containerColor = NavyCard, contentColor = TextHighContrast)
                            ) {
                                Text("Reset Emergency State")
                            }
                        }
                    }
                }

                EmergencyStatus.NO_NETWORK -> {
                    StatusFeedbackCard(
                        title = "No Internet Network Detected",
                        message = emergencyState.statusMessage,
                        color = AmberAccent,
                        onReset = { viewModel.emergencyManager.reset() }
                    )
                }

                EmergencyStatus.NOT_CONFIGURED -> {
                    StatusFeedbackCard(
                        title = "Emergency Contact Not Configured",
                        message = "Please configure an emergency phone number in Settings.",
                        color = AlertRed,
                        onReset = onNavigateToSettings
                    )
                }

                EmergencyStatus.FAILED, EmergencyStatus.PERMISSION_UNAVAILABLE -> {
                    StatusFeedbackCard(
                        title = "Emergency Action Incomplete",
                        message = emergencyState.statusMessage.ifBlank { "Unable to execute emergency action. Please call 911 directly." },
                        color = AlertRed,
                        onReset = { viewModel.emergencyManager.reset() }
                    )
                }
            }

            // Cancellation state confirmation
            if (emergencyState.status == EmergencyStatus.CANCELLED) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CyanAccent)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = emergencyState.statusMessage,
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextHighContrast)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun StatusFeedbackCard(
    title: String,
    message: String,
    color: Color,
    onReset: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, color),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextHighContrast,
                    textAlign = TextAlign.Center
                )
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = onReset,
                colors = ButtonDefaults.buttonColors(containerColor = NavyCard, contentColor = TextHighContrast)
            ) {
                Text("Dismiss / Configure")
            }
        }
    }
}
