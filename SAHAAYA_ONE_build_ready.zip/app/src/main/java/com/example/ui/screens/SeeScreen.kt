package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.AccessibilityProfile
import com.example.data.model.SeeAnalysisState
import com.example.data.model.SeeMode
import com.example.ui.SahaayaViewModel
import com.example.ui.components.CameraPreviewView
import com.example.ui.components.DemoStateBanner
import com.example.ui.components.SahaayaTopBar
import com.example.ui.components.SampleBitmaps
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.TextHighContrast
import com.example.ui.theme.TextMediumContrast

@Composable
fun SeeScreen(
    viewModel: SahaayaViewModel,
    onNavigateBack: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val seeState by viewModel.seeState.collectAsState()
    val preferences by viewModel.preferences.collectAsState()
    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsState()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            SahaayaTopBar(
                title = "SEE (Vision Companion)",
                currentProfile = preferences.selectedProfile,
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                isTtsSpeaking = isSpeaking,
                onStopTts = { viewModel.stopSpeaking() },
                onProfileClick = onProfileClick
            )
        },
        containerColor = NavyDeep,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (preferences.isDemoMode) {
                DemoStateBanner()
            }

            // Mode Tabs: DESCRIBE, READ, ASK
            val selectedTabIndex = when (seeState.mode) {
                is SeeMode.Describe -> 0
                is SeeMode.Read -> 1
                is SeeMode.Ask -> 2
            }

            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = NavySurface,
                contentColor = CyanAccent,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = CyanAccent,
                        height = 3.dp
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, NavyCardBorder, RoundedCornerShape(12.dp))
                    .testTag("see_mode_tabs")
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { viewModel.setSeeMode(SeeMode.Describe) },
                    text = {
                        Text(
                            "DESCRIBE",
                            fontWeight = FontWeight.Bold,
                            color = if (selectedTabIndex == 0) CyanAccent else TextMediumContrast
                        )
                    },
                    icon = { Icon(Icons.Default.Visibility, contentDescription = null) },
                    modifier = Modifier.testTag("tab_describe")
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { viewModel.setSeeMode(SeeMode.Read) },
                    text = {
                        Text(
                            "READ (OCR)",
                            fontWeight = FontWeight.Bold,
                            color = if (selectedTabIndex == 1) CyanAccent else TextMediumContrast
                        )
                    },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = null) },
                    modifier = Modifier.testTag("tab_read")
                )
                Tab(
                    selected = selectedTabIndex == 2,
                    onClick = { viewModel.setSeeMode(SeeMode.Ask) },
                    text = {
                        Text(
                            "ASK",
                            fontWeight = FontWeight.Bold,
                            color = if (selectedTabIndex == 2) CyanAccent else TextMediumContrast
                        )
                    },
                    icon = { Icon(Icons.Default.HelpOutline, contentDescription = null) },
                    modifier = Modifier.testTag("tab_ask")
                )
            }

            // Camera / Viewfinder Box
            if (seeState.capturedBitmap == null) {
                if (hasCameraPermission) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp)
                    ) {
                        CameraPreviewView(
                            onImageCaptured = { bmp ->
                                viewModel.setCapturedBitmap(bmp, isDemo = false)
                                viewModel.analyzeCapturedImage()
                            },
                            onDemoImageSelected = {
                                val demoBmp = SampleBitmaps.createDemoSceneBitmap()
                                viewModel.setCapturedBitmap(demoBmp, isDemo = true)
                                viewModel.analyzeCapturedImage()
                            },
                            isCapturing = seeState.isLoading
                        )
                    }
                } else {
                    // Camera permission requested state
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                tint = AmberAccent,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Camera Permission Required",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextHighContrast
                                )
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "SAHAAYA ONE requires camera access to describe surroundings and read printed text.",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMediumContrast),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyanAccent,
                                    contentColor = NavyDeep
                                )
                            ) {
                                Text("Grant Camera Permission", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                // Image has been captured or selected
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(NavySurface)
                        .border(1.dp, NavyCardBorder, RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    if (seeState.isDemoImage) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(AmberAccent.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                .border(1.dp, AmberAccent, RoundedCornerShape(6.dp))
                                .padding(6.dp)
                                .testTag("demo_image_badge"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "DEMO IMAGE — Sample Test Scene",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AmberAccent
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Image(
                        bitmap = seeState.capturedBitmap!!.asImageBitmap(),
                        contentDescription = "Captured scene for AI vision inspection",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                viewModel.setCapturedBitmap(null)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NavyCard,
                                contentColor = CyanAccent
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("retake_photo_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Retake Photo")
                        }

                        if (!seeState.isLoading) {
                            Button(
                                onClick = { viewModel.analyzeCapturedImage() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyanAccent,
                                    contentColor = NavyDeep
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("reanalyze_button")
                            ) {
                                Text("Re-Analyze", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Ask Mode specific prompt input field
            if (seeState.mode is SeeMode.Ask && seeState.capturedBitmap != null) {
                OutlinedTextField(
                    value = seeState.userQuestion,
                    onValueChange = { viewModel.setUserQuestion(it) },
                    label = { Text("Ask a question about this image") },
                    placeholder = { Text("e.g. Is the door open? What color is the bottle?") },
                    trailingIcon = {
                        IconButton(
                            onClick = { viewModel.analyzeCapturedImage() },
                            enabled = !seeState.isLoading
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Ask", tint = CyanAccent)
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanAccent,
                        unfocusedBorderColor = NavyCardBorder,
                        focusedTextColor = TextHighContrast,
                        unfocusedTextColor = TextHighContrast
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("see_ask_input_field")
                )
            }

            // Analysis Result / Loading / Error
            if (seeState.isLoading) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            color = CyanAccent,
                            modifier = Modifier.size(28.dp),
                            strokeWidth = 3.dp
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "Analyzing image with Vision AI...",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Medium,
                                color = TextHighContrast
                            )
                        )
                    }
                }
            }

            // Error Message (Must follow truthful failure wording: "AI analysis is unavailable. Please try again.")
            seeState.errorMessage?.let { error ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, AlertRed),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("see_error_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Notice",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = AlertRed
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = error,
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextHighContrast)
                        )
                    }
                }
            }

            // Result Text
            seeState.resultText?.let { result ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, CyanAccent),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("see_result_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when (seeState.mode) {
                                    is SeeMode.Describe -> "Scene Description"
                                    is SeeMode.Read -> "Extracted Text (OCR)"
                                    is SeeMode.Ask -> "Answer"
                                },
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CyanAccent
                                )
                            )

                            // Read Aloud / Stop Read Aloud Button
                            IconButton(
                                onClick = {
                                    if (isSpeaking) viewModel.stopSpeaking() else viewModel.speakText(result)
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .testTag("see_speak_result_button")
                                    .semantics {
                                        contentDescription = if (isSpeaking) "Stop speech" else "Read aloud"
                                    }
                            ) {
                                Icon(
                                    imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.VolumeUp,
                                    contentDescription = null,
                                    tint = if (isSpeaking) AlertRed else CyanAccent
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = result,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                color = TextHighContrast,
                                lineHeight = 24.sp
                            ),
                            modifier = Modifier.testTag("see_result_text")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
