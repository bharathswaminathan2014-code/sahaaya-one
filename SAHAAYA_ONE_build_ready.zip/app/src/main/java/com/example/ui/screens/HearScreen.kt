package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.EnvironmentalSoundEvent
import com.example.data.model.HearingTranscription
import com.example.ui.SahaayaViewModel
import com.example.ui.components.AudioWaveVisualizer
import com.example.ui.components.DemoStateBanner
import com.example.ui.components.SahaayaTopBar
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.TextHighContrast
import com.example.ui.theme.TextMediumContrast
import com.example.ui.theme.TextMuted
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HearScreen(
    viewModel: SahaayaViewModel,
    onNavigateBack: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val preferences by viewModel.preferences.collectAsState()
    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsState()

    val isListening by viewModel.speechManager.isListening.collectAsState()
    val liveTranscript by viewModel.speechManager.liveTranscript.collectAsState()
    val conversationHistory by viewModel.speechManager.conversationHistory.collectAsState()
    val soundEvents by viewModel.speechManager.soundEvents.collectAsState()
    val audioLevel by viewModel.speechManager.audioLevel.collectAsState()
    val errorMessage by viewModel.speechManager.errorMessage.collectAsState()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasMicPermission) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Scaffold(
        topBar = {
            SahaayaTopBar(
                title = "HEAR (Sound & Captions)",
                currentProfile = preferences.selectedProfile,
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                isTtsSpeaking = isSpeaking,
                onStopTts = { viewModel.stopSpeaking() },
                onProfileClick = onProfileClick
            )
        },
        containerColor = NavyDeep,
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                if (preferences.isDemoMode) {
                    DemoStateBanner()
                }
            }

            // Real-Time Audio Visualizer & Mic Control Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    border = androidx.compose.foundation.BorderStroke(
                        width = 1.5.dp,
                        color = if (isListening) AmberAccent else NavyCardBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (isListening) "Listening for Speech & Acoustic Events..." else "Microphone Idle — Tap to Listen",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isListening) AmberAccent else TextMediumContrast
                            )
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Animated Audio Waveform
                        AudioWaveVisualizer(
                            audioLevel = if (isListening) audioLevel else 0f,
                            modifier = Modifier.testTag("hear_audio_visualizer")
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Large Accessible Mic Toggle Button (min 64dp)
                        Button(
                            onClick = {
                                if (!hasMicPermission) {
                                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                } else {
                                    viewModel.toggleListening()
                                }
                            },
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isListening) AlertRed else AmberAccent,
                                contentColor = NavyDeep
                            ),
                            modifier = Modifier
                                .size(68.dp)
                                .testTag("hear_mic_toggle_button")
                                .semantics {
                                    contentDescription = if (isListening) "Stop listening" else "Start speech recognition"
                                }
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = null,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (isListening) "Tap to pause" else "Tap to start listening",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                        )
                    }
                }
            }

            // Live Caption Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Live Captions",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AmberAccent
                                )
                            )
                            if (liveTranscript.isNotBlank()) {
                                IconButton(
                                    onClick = { viewModel.speakText(liveTranscript) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = "Read caption aloud",
                                        tint = CyanAccent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = liveTranscript.ifBlank {
                                errorMessage ?: if (isListening) "Listening for nearby voice..." else "No active speech. Press the microphone button above to start."
                            },
                            style = MaterialTheme.typography.bodyLarge.copy(
                                color = if (liveTranscript.isBlank()) TextMuted else TextHighContrast,
                                lineHeight = 22.sp
                            ),
                            modifier = Modifier.testTag("hear_live_transcript")
                        )
                    }
                }
            }

            // Environmental Sound Events
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Assistive Acoustic Cues",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    )

                    // Quick test cue buttons
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TestCueButton("Doorbell") {
                            viewModel.speechManager.addManualAssistiveSoundEvent("Possible doorbell detected.")
                        }
                        TestCueButton("Siren") {
                            viewModel.speechManager.addManualAssistiveSoundEvent("Possible siren detected.")
                        }
                        TestCueButton("Horn") {
                            viewModel.speechManager.addManualAssistiveSoundEvent("Possible vehicle horn detected.")
                        }
                    }
                }
            }

            if (soundEvents.isEmpty()) {
                item {
                    Text(
                        text = "No sound events detected yet. Sudden loud spikes or test buttons will show assistive cues here.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                    )
                }
            } else {
                items(soundEvents.reversed()) { event ->
                    SoundEventItem(event)
                }
            }

            // Conversation History Log
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Conversation Log",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextHighContrast
                        )
                    )
                    if (conversationHistory.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.clearHearingHistory() },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("clear_hearing_history_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Clear History",
                                tint = AlertRed,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            if (conversationHistory.isEmpty()) {
                item {
                    Text(
                        text = "Completed sentences will appear here in the conversation log.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                    )
                }
            } else {
                items(conversationHistory.reversed()) { item ->
                    ConversationHistoryCard(item)
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun TestCueButton(label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = NavyCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder)
    ) {
        Text(
            text = "+$label",
            style = MaterialTheme.typography.labelSmall.copy(color = CyanAccent),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun SoundEventItem(event: EnvironmentalSoundEvent) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, AmberAccent),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("sound_event_${event.id}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.NotificationsActive,
                contentDescription = null,
                tint = AmberAccent,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = event.label,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextHighContrast
                    )
                )
                Text(
                    text = "${event.confidence} • ${formatTimestamp(event.timestamp)}",
                    style = MaterialTheme.typography.labelSmall.copy(color = AmberAccent)
                )
            }
        }
    }
}

@Composable
private fun ConversationHistoryCard(item: HearingTranscription) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = item.speaker,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = CyanAccent,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = formatTimestamp(item.timestamp),
                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = item.text,
                style = MaterialTheme.typography.bodyMedium.copy(color = TextHighContrast)
            )
        }
    }
}

private fun formatTimestamp(millis: Long): String {
    val formatter = SimpleDateFormat("h:mm:ss a", Locale.getDefault())
    return formatter.format(Date(millis))
}
