package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccessibilityProfile
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.TextHighContrast
import com.example.ui.theme.TextMediumContrast

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SahaayaTopBar(
    title: String,
    currentProfile: AccessibilityProfile,
    canNavigateBack: Boolean,
    onNavigateBack: () -> Unit,
    isTtsSpeaking: Boolean = false,
    onStopTts: () -> Unit = {},
    onProfileClick: () -> Unit = {}
) {
    TopAppBar(
        title = {
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextHighContrast
                    ),
                    modifier = Modifier.testTag("top_bar_title")
                )
                Text(
                    text = "Profile: ${currentProfile.title}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = CyanAccent,
                        fontWeight = FontWeight.Medium
                    )
                )
            }
        },
        navigationIcon = {
            if (canNavigateBack) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("top_bar_back_button")
                        .semantics { contentDescription = "Navigate back" }
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextHighContrast
                    )
                }
            }
        },
        actions = {
            if (isTtsSpeaking) {
                IconButton(
                    onClick = onStopTts,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("stop_speech_button")
                        .semantics { contentDescription = "Stop speaking" }
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop Speech",
                        tint = AlertRed
                    )
                }
            }
            ProfileChip(
                profile = currentProfile,
                onClick = onProfileClick
            )
            Spacer(modifier = Modifier.width(8.dp))
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = NavySurface,
            titleContentColor = TextHighContrast
        )
    )
}

@Composable
fun ProfileChip(
    profile: AccessibilityProfile,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (badgeColor, badgeIcon) = when (profile) {
        AccessibilityProfile.VISUAL -> CyanAccent to Icons.Default.Visibility
        AccessibilityProfile.HEARING -> AmberAccent to Icons.Default.Hearing
        AccessibilityProfile.COMMUNICATION -> Color(0xFF64FFDA) to Icons.Default.RecordVoiceOver
        AccessibilityProfile.MULTIPLE -> Color(0xFFFF80BF) to Icons.Default.VolumeUp
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = NavyCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, badgeColor),
        modifier = modifier
            .testTag("profile_chip_${profile.name.lowercase()}")
            .semantics { contentDescription = "Current profile ${profile.title}. Tap to change." }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Icon(
                imageVector = badgeIcon,
                contentDescription = null,
                tint = badgeColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = profile.title,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextHighContrast
                )
            )
        }
    }
}

@Composable
fun AudioWaveVisualizer(
    audioLevel: Float, // 0.0 to 1.0
    modifier: Modifier = Modifier
) {
    val animatedLevel by animateFloatAsState(targetValue = audioLevel, label = "audio_level")

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .background(NavyCard, RoundedCornerShape(12.dp))
            .border(1.dp, NavyCardBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val barCount = 12
        for (i in 0 until barCount) {
            val factor = ((i % 4) + 1) * 0.25f
            val barHeight = (12.dp + (32.dp * (animatedLevel * factor))).coerceIn(6.dp, 36.dp)
            val barColor = if (animatedLevel > 0.6f) AlertRed else CyanAccent
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .height(barHeight)
                    .clip(RoundedCornerShape(3.dp))
                    .background(barColor)
            )
        }
    }
}

@Composable
fun DemoStateBanner(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(AmberAccent.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
            .border(1.dp, AmberAccent, RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("demo_state_banner"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "DEMO STATE — Simulated Hardware Telemetry",
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                color = AmberAccent,
                letterSpacing = 1.sp
            )
        )
    }
}
