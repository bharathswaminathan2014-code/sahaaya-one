package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccessibilityProfile
import com.example.data.model.HapticPatternType
import com.example.ui.SahaayaViewModel
import com.example.ui.components.DemoStateBanner
import com.example.ui.components.SahaayaTopBar
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.TextHighContrast
import com.example.ui.theme.TextMediumContrast
import com.example.ui.theme.TextMuted

@Composable
fun SettingsScreen(
    viewModel: SahaayaViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToProfileSelection: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val preferences by viewModel.preferences.collectAsState()
    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsState()

    var contactName by remember(preferences.emergencyContactName) { mutableStateOf(preferences.emergencyContactName) }
    var contactPhone by remember(preferences.emergencyContactPhone) { mutableStateOf(preferences.emergencyContactPhone) }
    var backendUrl by remember(preferences.backendUrl) { mutableStateOf(preferences.backendUrl) }

    var ttsRate by remember(preferences.ttsRate) { mutableFloatStateOf(preferences.ttsRate) }
    var ttsPitch by remember(preferences.ttsPitch) { mutableFloatStateOf(preferences.ttsPitch) }
    var hapticIntensity by remember(preferences.hapticIntensity) { mutableFloatStateOf(preferences.hapticIntensity) }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            SahaayaTopBar(
                title = "Settings & Accessibility",
                currentProfile = preferences.selectedProfile,
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                isTtsSpeaking = isSpeaking,
                onStopTts = { viewModel.stopSpeaking() },
                onProfileClick = onProfileClick
            )
        },
        containerColor = NavyDeep,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            if (preferences.isDemoMode) {
                DemoStateBanner()
            }

            // Current Accessibility Profile Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Active Profile",
                            style = MaterialTheme.typography.titleSmall.copy(color = CyanAccent)
                        )
                        Text(
                            text = preferences.selectedProfile.title,
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextHighContrast
                            )
                        )
                        Text(
                            text = preferences.selectedProfile.description,
                            style = MaterialTheme.typography.bodySmall.copy(color = TextMediumContrast)
                        )
                    }

                    Button(
                        onClick = onNavigateToProfileSelection,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = NavyDeep),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Change", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // High Contrast & Display
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Visual Display Options",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = AmberAccent
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "High Contrast Mode",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextHighContrast
                                )
                            )
                            Text(
                                text = "Enhances border contrast and font readability",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                            )
                        }
                        Switch(
                            checked = preferences.highContrastEnabled,
                            onCheckedChange = { viewModel.setHighContrast(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = NavyDeep,
                                checkedTrackColor = CyanAccent
                            )
                        )
                    }
                }
            }

            // Text-to-Speech Settings
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Speech Output (Text-to-Speech)",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Speech Rate: ${(ttsRate * 10).toInt() / 10f}x",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextHighContrast)
                    )
                    Slider(
                        value = ttsRate,
                        onValueChange = {
                            ttsRate = it
                            viewModel.updateTtsSettings(ttsRate, ttsPitch)
                        },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Speech Pitch: ${(ttsPitch * 10).toInt() / 10f}",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextHighContrast)
                    )
                    Slider(
                        value = ttsPitch,
                        onValueChange = {
                            ttsPitch = it
                            viewModel.updateTtsSettings(ttsRate, ttsPitch)
                        },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = AmberAccent, activeTrackColor = AmberAccent)
                    )

                    Button(
                        onClick = { viewModel.speakText("This is a sample audio test for SAHAAYA ONE speech output.") },
                        colors = ButtonDefaults.buttonColors(containerColor = NavyCard, contentColor = CyanAccent),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Speech Output")
                    }
                }
            }

            // Haptic Feedback Settings
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Phone Haptic Feedback",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = AmberAccent
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Haptic Intensity: ${(hapticIntensity * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextHighContrast)
                    )

                    Slider(
                        value = hapticIntensity,
                        onValueChange = {
                            hapticIntensity = it
                            viewModel.updateHapticIntensity(it)
                        },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(thumbColor = AmberAccent, activeTrackColor = AmberAccent)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.hapticManager.triggerPattern(HapticPatternType.NOTIFICATION, hapticIntensity) },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyCard, contentColor = TextHighContrast),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Test 1 Pulse", fontSize = 12.sp)
                        }
                        Button(
                            onClick = { viewModel.hapticManager.triggerPattern(HapticPatternType.IMPORTANT_ALERT, hapticIntensity) },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyCard, contentColor = AmberAccent),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Test Long Pulse", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Emergency Contact Configuration
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Emergency Contact Setup",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = AlertRed
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = contactName,
                        onValueChange = {
                            contactName = it
                            viewModel.setEmergencyContact(contactName, contactPhone)
                        },
                        label = { Text("Contact Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = NavyCardBorder,
                            focusedTextColor = TextHighContrast,
                            unfocusedTextColor = TextHighContrast
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = contactPhone,
                        onValueChange = {
                            contactPhone = it
                            viewModel.setEmergencyContact(contactName, contactPhone)
                        },
                        label = { Text("Emergency Phone Number") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = NavyCardBorder,
                            focusedTextColor = TextHighContrast,
                            unfocusedTextColor = TextHighContrast
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Backend Service Configuration
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Backend Service Endpoint",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "SAHAAYA ONE cloud AI proxy URL:",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = backendUrl,
                        onValueChange = {
                            backendUrl = it
                            viewModel.setBackendUrl(backendUrl)
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = NavyCardBorder,
                            focusedTextColor = TextHighContrast,
                            unfocusedTextColor = TextHighContrast
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
