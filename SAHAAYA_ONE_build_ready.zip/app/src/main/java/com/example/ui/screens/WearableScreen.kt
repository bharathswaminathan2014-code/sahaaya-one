package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.BleDeviceItem
import com.example.data.model.WearableConnectionState
import com.example.ui.SahaayaViewModel
import com.example.ui.components.DemoStateBanner
import com.example.ui.components.SahaayaTopBar
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextHighContrast
import com.example.ui.theme.TextMediumContrast
import com.example.ui.theme.TextMuted

@Composable
fun WearableScreen(
    viewModel: SahaayaViewModel,
    onNavigateBack: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val preferences by viewModel.preferences.collectAsState()
    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsState()

    val wearableService = viewModel.activeWearableService
    val telemetry by wearableService.telemetry.collectAsState()
    val scannedDevices by wearableService.scannedDevices.collectAsState()
    val isScanning by wearableService.isScanning.collectAsState()
    val logs by wearableService.logMessages.collectAsState()

    val blePermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        listOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        )
    } else {
        listOf(
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        wearableService.startScan()
    }

    Scaffold(
        topBar = {
            SahaayaTopBar(
                title = "Wearable Companion",
                currentProfile = preferences.selectedProfile,
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                isTtsSpeaking = isSpeaking,
                onStopTts = { viewModel.stopSpeaking() },
                onProfileClick = onProfileClick
            )
        },
        containerColor = NavyDeep,
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                if (preferences.isDemoMode || telemetry.isDemoState) {
                    DemoStateBanner()
                }
            }

            // Mode Selector: Real BLE vs Demo Mode
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .padding(14.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Wearable Demo Mode",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextHighContrast
                                )
                            )
                            Text(
                                text = if (preferences.isDemoMode) "Simulating ESP32-S3 hardware" else "Using real Bluetooth LE antenna",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMediumContrast)
                            )
                        }
                        Switch(
                            checked = preferences.isDemoMode,
                            onCheckedChange = { viewModel.setDemoMode(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = NavyDeep,
                                checkedTrackColor = AmberAccent
                            ),
                            modifier = Modifier.testTag("wearable_demo_mode_switch")
                        )
                    }
                }
            }

            // Hardware Telemetry Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    border = androidx.compose.foundation.BorderStroke(
                        width = 1.5.dp,
                        color = if (telemetry.isConnected) (if (telemetry.isDemoState) AmberAccent else CyanAccent) else AlertRed
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Watch,
                                    contentDescription = null,
                                    tint = if (telemetry.isConnected) CyanAccent else TextMuted,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = telemetry.deviceName,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextHighContrast
                                        )
                                    )
                                    Text(
                                        text = if (telemetry.isDemoState) "DEMO STATE • ESP32-S3 Class" else "BLE Physical Peripheral",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (telemetry.isDemoState) AmberAccent else CyanAccent,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }

                            // Connection Badge
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = when (telemetry.connectionState) {
                                    WearableConnectionState.CONNECTED -> SuccessGreen.copy(alpha = 0.2f)
                                    WearableConnectionState.CONNECTING -> AmberAccent.copy(alpha = 0.2f)
                                    WearableConnectionState.SCANNING -> CyanAccent.copy(alpha = 0.2f)
                                    else -> AlertRed.copy(alpha = 0.2f)
                                },
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    when (telemetry.connectionState) {
                                        WearableConnectionState.CONNECTED -> SuccessGreen
                                        WearableConnectionState.CONNECTING -> AmberAccent
                                        WearableConnectionState.SCANNING -> CyanAccent
                                        else -> AlertRed
                                    }
                                )
                            ) {
                                Text(
                                    text = telemetry.connectionState.name,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextHighContrast
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Telemetry Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TelemetryMetric(
                                label = "Battery",
                                value = if (telemetry.isConnected && telemetry.batteryPercent >= 0) "${telemetry.batteryPercent}%" else "--",
                                icon = Icons.Default.BatteryChargingFull,
                                color = if (telemetry.batteryPercent > 20) SuccessGreen else AlertRed
                            )
                            TelemetryMetric(
                                label = "Button Clicks",
                                value = if (telemetry.isConnected) "${telemetry.buttonPressCount}" else "--",
                                icon = Icons.Default.CheckCircle,
                                color = CyanAccent
                            )
                            TelemetryMetric(
                                label = "Vibration Motor",
                                value = if (telemetry.hapticMotorReady) "Ready" else "Off",
                                icon = Icons.Default.Vibration,
                                color = AmberAccent
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Interactive hardware buttons for demo / testing
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { wearableService.triggerSimulatedButton() },
                                colors = ButtonDefaults.buttonColors(containerColor = NavyCard, contentColor = TextHighContrast),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("wearable_trigger_button_event")
                            ) {
                                Text("Trigger Button", fontSize = 12.sp)
                            }

                            Button(
                                onClick = { wearableService.sendHapticCommand(1.0f) },
                                colors = ButtonDefaults.buttonColors(containerColor = NavyCard, contentColor = AmberAccent),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("wearable_send_haptic_command")
                            ) {
                                Text("Pulse Haptic", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // BLE Scanning & Device Discovery
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Bluetooth LE Scan",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    )

                    Button(
                        onClick = {
                            if (preferences.isDemoMode) {
                                wearableService.startScan()
                            } else {
                                val hasPermissions = blePermissions.all {
                                    ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
                                }
                                if (hasPermissions) {
                                    wearableService.startScan()
                                } else {
                                    permissionLauncher.launch(blePermissions.toTypedArray())
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyanAccent,
                            contentColor = NavyDeep
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("start_ble_scan_button")
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(color = NavyDeep, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Scanning...")
                        } else {
                            Icon(Icons.Default.BluetoothSearching, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Scan BLE Devices")
                        }
                    }
                }
            }

            if (scannedDevices.isEmpty()) {
                item {
                    Text(
                        text = "No wearable devices discovered. Tap 'Scan BLE Devices' to scan for ESP32-S3 wearable peripherals.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                    )
                }
            } else {
                items(scannedDevices) { dev ->
                    BleDeviceRow(
                        device = dev,
                        onConnect = { wearableService.connectDevice(dev.address) }
                    )
                }
            }

            // Activity Log
            item {
                Text(
                    text = "Wearable Service Logs",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextMediumContrast
                    )
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .padding(12.dp)
                            .fillMaxWidth()
                    ) {
                        logs.takeLast(6).forEach { log ->
                            Text(
                                text = log,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (log.contains("DEMO")) AmberAccent else TextMediumContrast,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun TelemetryMetric(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = color))
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
    }
}

@Composable
private fun BleDeviceRow(
    device: BleDeviceItem,
    onConnect: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = device.name,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextHighContrast
                    )
                )
                Text(
                    text = "${device.address} • RSSI: ${device.rssi} dBm",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                )
            }

            Button(
                onClick = onConnect,
                colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = NavyDeep),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Connect", fontSize = 12.sp)
            }
        }
    }
}
