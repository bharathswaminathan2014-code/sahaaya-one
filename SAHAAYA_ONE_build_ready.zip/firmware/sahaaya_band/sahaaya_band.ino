/*
  SAHAAYA Band - Tier A firmware (1 button + 1 vibration motor) for ESP32-S3

  STATUS: written to match the SAHAAYA ONE Android app. NOT yet tested on real hardware.
  Written for the Arduino-ESP32 core 2.0.17 (also guarded for 3.x).

  Boards: Seeed XIAO ESP32S3, or any ESP32-S3 dev board.
  Wiring (same GPIO numbers on both boards):
    Button  : GPIO 4  (XIAO pad D3) -> one leg; other leg -> GND      (internal pull-up used)
    Motor   : GPIO 5  (XIAO pad D4) -> vibration-motor MODULE signal pin (module VCC->3V3, GND->GND)
              (or: GPIO5 -> 1k resistor -> NPN transistor base, motor between 3V3 and collector,
               emitter -> GND, 1N4148 diode across the motor, stripe toward 3V3)
    Battery : OPTIONAL. 100k + 100k divider from battery + to GPIO 1 (XIAO pad D0). Then set BATTERY_ADC_PIN 1.

  BLE (must match BluetoothWearableService.kt in the app):
    Service  7d1f0001-3b5a-4c1e-9a10-5a4a4f4e4531
      Button  ...0002  NOTIFY   1 byte: 1 = single press, 2 = double press, 3 = long press
      Haptic  ...0003  WRITE    2 bytes: [pattern, intensity 0-100]
                                pattern 0 = stop, 1 = notification, 2 = activity, 3 = important,
                                        4 = emergency, 5 = high priority
      Battery ...0004  NOTIFY   1 byte: 0-100 percent, or 255 = unknown (no battery circuit)
*/

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>

#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  #define CORE_V3 1
#else
  #define CORE_V3 0
  #include <BLE2902.h>
#endif

// ---------- Settings you may change ----------
#define DEVICE_NAME       "SAHAAYA-Band"
#define BUTTON_PIN        4
#define MOTOR_PIN         5
#define BATTERY_ADC_PIN   -1      // set to 1 if you built the 100k/100k divider
#define LOCAL_FEEDBACK    1       // short buzz on every button event so the wearer feels it registered

#define SERVICE_UUID  "7d1f0001-3b5a-4c1e-9a10-5a4a4f4e4531"
#define BUTTON_UUID   "7d1f0002-3b5a-4c1e-9a10-5a4a4f4e4531"
#define HAPTIC_UUID   "7d1f0003-3b5a-4c1e-9a10-5a4a4f4e4531"
#define BATTERY_UUID  "7d1f0004-3b5a-4c1e-9a10-5a4a4f4e4531"

const uint32_t DEBOUNCE_MS   = 30;
const uint32_t DOUBLE_GAP_MS = 350;
const uint32_t LONG_PRESS_MS = 1500;

// ---------- Globals ----------
BLECharacteristic* buttonChar  = nullptr;
BLECharacteristic* batteryChar = nullptr;
bool phoneConnected = false;

void startHaptic(uint8_t pattern, uint8_t intensityPct);

// ---------- Motor (PWM) ----------
static inline void motorWrite(uint8_t duty) {
#if CORE_V3
  ledcWrite(MOTOR_PIN, duty);
#else
  ledcWrite(0, duty);
#endif
}

void motorInit() {
#if CORE_V3
  ledcAttach(MOTOR_PIN, 20000, 8);
#else
  ledcSetup(0, 20000, 8);
  ledcAttachPin(MOTOR_PIN, 0);
#endif
  motorWrite(0);
}

// ---------- Haptic patterns: alternating ON / OFF durations in ms, starting with ON ----------
static const uint16_t P_NOTIFY[]    = {120};
static const uint16_t P_ACTIVITY[]  = {100, 100, 100};
static const uint16_t P_IMPORTANT[] = {600};
static const uint16_t P_EMERGENCY[] = {200, 150, 200, 150, 200};
static const uint16_t P_PRIORITY[]  = {250, 150, 250, 150, 250, 150, 250, 150, 250};

const uint16_t* curSteps = nullptr;
uint8_t  curLen  = 0;
uint8_t  curIdx  = 0;
uint8_t  curDuty = 0;
uint32_t stepEnd = 0;

void startHaptic(uint8_t pattern, uint8_t intensityPct) {
  motorWrite(0);
  curSteps = nullptr;
  switch (pattern) {
    case 1: curSteps = P_NOTIFY;    curLen = sizeof(P_NOTIFY)    / sizeof(uint16_t); break;
    case 2: curSteps = P_ACTIVITY;  curLen = sizeof(P_ACTIVITY)  / sizeof(uint16_t); break;
    case 3: curSteps = P_IMPORTANT; curLen = sizeof(P_IMPORTANT) / sizeof(uint16_t); break;
    case 4: curSteps = P_EMERGENCY; curLen = sizeof(P_EMERGENCY) / sizeof(uint16_t); break;
    case 5: curSteps = P_PRIORITY;  curLen = sizeof(P_PRIORITY)  / sizeof(uint16_t); break;
    default: return;   // 0 or unknown = stop
  }
  if (intensityPct > 100) intensityPct = 100;
  if (intensityPct == 0) { curSteps = nullptr; return; }
  // Small motors need a minimum duty to spin, so map 1-100% onto 80-255.
  curDuty = 80 + (uint16_t)intensityPct * (255 - 80) / 100;
  curIdx = 0;
  motorWrite(curDuty);
  stepEnd = millis() + curSteps[0];
}

void updateHaptic() {
  if (curSteps == nullptr) return;
  if ((int32_t)(millis() - stepEnd) < 0) return;
  curIdx++;
  if (curIdx >= curLen) {
    motorWrite(0);
    curSteps = nullptr;
    return;
  }
  motorWrite((curIdx % 2 == 0) ? curDuty : 0);
  stepEnd = millis() + curSteps[curIdx];
}

// ---------- BLE callbacks ----------
class ServerCb : public BLEServerCallbacks {
  void onConnect(BLEServer*) override {
    phoneConnected = true;
    Serial.println("BLE: phone connected");
  }
  void onDisconnect(BLEServer*) override {
    phoneConnected = false;
    Serial.println("BLE: phone disconnected, advertising again");
    BLEDevice::startAdvertising();
  }
};

class HapticCb : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* c) override {
    uint8_t* d = c->getData();
    size_t n = c->getLength();
    if (d == nullptr || n < 1) return;
    uint8_t pattern = d[0];
    uint8_t level = (n >= 2) ? d[1] : 100;
    Serial.printf("Haptic write: pattern %u, level %u\n", pattern, level);
    startHaptic(pattern, level);
  }
};

// ---------- Button (single / double / long) ----------
void sendButtonEvent(uint8_t code) {
  Serial.printf("Button event %u\n", code);
  buttonChar->setValue(&code, 1);
  if (phoneConnected) buttonChar->notify();
#if LOCAL_FEEDBACK
  startHaptic(1, 60);
#endif
}

bool     lastRaw = HIGH, stableState = HIGH, longFired = false;
uint32_t lastChange = 0, pressStart = 0, lastRelease = 0;
uint8_t  clicks = 0;

void updateButton() {
  bool raw = digitalRead(BUTTON_PIN);
  uint32_t now = millis();

  if (raw != lastRaw) { lastRaw = raw; lastChange = now; }

  if ((now - lastChange) >= DEBOUNCE_MS && raw != stableState) {
    stableState = raw;
    if (stableState == LOW) {            // pressed
      pressStart = now;
      longFired = false;
    } else {                             // released
      if (!longFired) { clicks++; lastRelease = now; }
    }
  }

  // Long press fires while still held
  if (stableState == LOW && !longFired && (now - pressStart) >= LONG_PRESS_MS) {
    longFired = true;
    clicks = 0;
    sendButtonEvent(3);
  }

  // Decide single vs double once the gap has passed
  if (clicks > 0 && stableState == HIGH && (now - lastRelease) >= DOUBLE_GAP_MS) {
    sendButtonEvent(clicks >= 2 ? 2 : 1);
    clicks = 0;
  }
}

// ---------- Battery ----------
uint8_t readBatteryPercent() {
#if BATTERY_ADC_PIN >= 0
  uint32_t mv = analogReadMilliVolts(BATTERY_ADC_PIN) * 2;      // 100k/100k divider
  long pct = ((long)mv - 3300) * 100L / (4150 - 3300);
  if (pct < 0) pct = 0;
  if (pct > 100) pct = 100;
  return (uint8_t)pct;
#else
  return 255;                                                    // unknown
#endif
}

uint32_t lastBatteryReport = 0;
void updateBattery() {
  uint32_t now = millis();
  if (now - lastBatteryReport < 5000) return;
  lastBatteryReport = now;
  uint8_t b = readBatteryPercent();
  batteryChar->setValue(&b, 1);
  if (phoneConnected) batteryChar->notify();
}

// ---------- Arduino entry points ----------
void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  motorInit();

  BLEDevice::init(DEVICE_NAME);
  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCb());

  BLEService* service = server->createService(SERVICE_UUID);

  buttonChar = service->createCharacteristic(
      BUTTON_UUID, BLECharacteristic::PROPERTY_NOTIFY | BLECharacteristic::PROPERTY_READ);
  batteryChar = service->createCharacteristic(
      BATTERY_UUID, BLECharacteristic::PROPERTY_NOTIFY | BLECharacteristic::PROPERTY_READ);
  BLECharacteristic* hapticChar = service->createCharacteristic(
      HAPTIC_UUID, BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  hapticChar->setCallbacks(new HapticCb());

#if !CORE_V3
  buttonChar->addDescriptor(new BLE2902());     // 3.x adds this automatically
  batteryChar->addDescriptor(new BLE2902());
#endif

  uint8_t zero = 0;
  buttonChar->setValue(&zero, 1);
  uint8_t unknownBattery = readBatteryPercent();
  batteryChar->setValue(&unknownBattery, 1);

  service->start();

  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(SERVICE_UUID);
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();

  Serial.println("SAHAAYA Band ready. Advertising as " DEVICE_NAME);
  startHaptic(2, 100);   // boot buzz: two short pulses = motor wiring works
}

void loop() {
  updateButton();
  updateHaptic();
  updateBattery();
  delay(2);
}
