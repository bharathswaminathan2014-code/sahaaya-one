# SAHAAYA Band - Tier A (button + vibration) build guide

Status: written to match the app, **not yet tested on real hardware**. Expect to debug a little.

## Parts (approx. INR - check current prices)
| Part | Notes | Approx. |
|---|---|---|
| Seeed XIAO ESP32S3 (plain, not "Sense") | Tiny, has a built-in LiPo charger. Any ESP32-S3 board also works | 800-1,200 |
| Vibration motor **module** (3V coin motor with driver) | Easiest. Bare motor needs a transistor + diode (see sketch header) | 100-150 |
| Tactile push button (or 2) | | 10-20 |
| Protected 3.7 V LiPo, 300-500 mAh, JST/bare leads | **Must have a protection circuit.** Check polarity | 300-500 |
| Wires, small perfboard, soldering iron if you do not have one | | 300-1,000 |
| Wrist strap / 3D-printed case | | 500-1,200 |

Until you have a battery, power the board from USB (laptop or power bank).

## Wiring (same GPIO numbers on XIAO and generic ESP32-S3 boards)
- Button: GPIO 4 (XIAO pad **D3**) to one leg, other leg to **GND**.
- Motor module: signal to GPIO 5 (XIAO pad **D4**), VCC to **3V3**, GND to **GND**.
- Battery (XIAO): protected LiPo to the **BAT+ / BAT-** pads on the back. Red = +. Double-check polarity before connecting.
- Optional battery gauge: 100k + 100k resistors as a divider from BAT+ to GPIO 1 (pad D0) to GND, then set `BATTERY_ADC_PIN 1` in the sketch. Without it the app shows "--" for battery.

## Flash the firmware (on your Windows computer)
1. Install **Arduino IDE 2.x**.
2. File > Preferences > "Additional boards manager URLs": add
   `https://espressif.github.io/arduino-esp32/package_esp32_index.json`
3. Tools > Board > Boards Manager: search **esp32** (by Espressif Systems), install version **2.0.17**.
4. Put `sahaaya_band.ino` in a folder named exactly `sahaaya_band` and open it.
5. Tools > Board > esp32 > **XIAO_ESP32S3** (or "ESP32S3 Dev Module"). Tools > **USB CDC On Boot: Enabled**.
6. Plug in the board, pick its port, click **Upload**.
7. Open Serial Monitor at 115200. You should see `SAHAAYA Band ready` and feel **two short buzzes**.

## Test the band alone, before using the app
Install the free **nRF Connect for Mobile** app (Nordic) on your phone.
1. Scan, find **SAHAAYA-Band**, Connect, open the service starting `7d1f0001`.
2. Button characteristic (`...0002`): tap the triple-arrow to subscribe. Press the button:
   single press shows `01`, double press `02`, hold 1.5 s `03`.
3. Haptic characteristic (`...0003`): tap the up-arrow, choose byte array, write `0264` (two pulses, full strength) or `0364` (one long buzz).

## Use with SAHAAYA ONE
1. Install the updated APK. In the app: Wearable screen, turn **Demo Mode off**, allow Bluetooth permissions, tap Scan, tap the band, Connect. The log on that screen shows what happens.
2. Open **SEE** and keep the screen on. Then:
   - **Single press** on the band: takes a photo and describes it.
   - **Double press**: takes a photo and reads the text in it.
   - **Long press (1.5 s)**: starts an emergency *request*. You still confirm on the phone.
3. The band vibrates when a result arrives (short double pulse), when there is an error (long buzz), and when an emergency request starts.

## Known limits
- Button presses trigger the camera only while the **SEE screen is open** with the screen on. Working with the phone locked needs more Android work.
- The emergency feature only opens the phone dialer. Set the number in Settings to **112** (default is 911).
- If the connection fails with "status 133": try again, or turn phone Bluetooth off and on.
- LiPo safety: use only protected cells, never puncture or short them, do not leave charging unattended.
- This is a prototype for demonstration, not a safety device.
